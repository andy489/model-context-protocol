import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import type { Root } from "@modelcontextprotocol/sdk/types.js";
import * as fs from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";

const server = new McpServer({
  name: "Root File Scanner",
  version: "1.0.0",
});

let roots: Root[] = [];

server.server.oninitialized = async () => {
  const caps = server.server.getClientCapabilities();
  if (!caps?.roots) {
    console.error("Client does not support roots. The scan-roots tool will return no results.");
    return;
  }
  const result = await server.server.listRoots();
  roots = result.roots;
  console.error(`Roots initialized: ${roots.length} root(s) registered.`);
};

server.registerTool(
  "scan-roots",
  {
    description:
      "Scans all client-declared roots and returns a filesystem summary: file counts, dir counts, total size, and the top 5 largest files per root. The server only accesses paths the client has explicitly declared as roots.",
  },
  async () => {
    if (roots.length === 0) {
      return {
        content: [{ type: "text", text: "No roots are currently declared by the client." }],
      };
    }

    const lines = scanRoots(roots);

    return {
      content: [{ type: "text", text: lines.join("\n") }],
    };
  },
);

const transport = new StdioServerTransport();
await server.connect(transport);


interface FileEntry {
  path: string;
  bytes: number;
}

interface ScanResult {
  rootUri: string;
  rootName: string | undefined;
  fileCount: number;
  dirCount: number;
  totalBytes: number;
  top5Largest: FileEntry[];
}

function scanRoots(roots: Root[]): string[] {
  const results: ScanResult[] = [];

    for (const root of roots) {
      let dirPath: string;
      try {
        dirPath = fileURLToPath(root.uri);
      } catch {
        results.push({
          rootUri: root.uri,
          rootName: root.name,
          fileCount: 0,
          dirCount: 0,
          totalBytes: 0,
          top5Largest: [],
        });
        continue;
      }

      const scan = scanDirectory(dirPath);
      results.push({ rootUri: root.uri, rootName: root.name, ...scan });
    }

    const lines: string[] = [];
    for (const r of results) {
      lines.push(`Root: ${r.rootName ?? r.rootUri}`);
      lines.push(`  URI:        ${r.rootUri}`);
      lines.push(`  Files:      ${r.fileCount}`);
      lines.push(`  Dirs:       ${r.dirCount}`);
      lines.push(`  Total size: ${formatBytes(r.totalBytes)}`);
      if (r.top5Largest.length > 0) {
        lines.push(`  Top ${r.top5Largest.length} largest files:`);
        for (const f of r.top5Largest) {
          lines.push(`    ${formatBytes(f.bytes).padStart(10)}  ${f.path}`);
        }
      }
      lines.push("");
    }

    return lines;
}

function scanDirectory(dirPath: string): Omit<ScanResult, "rootUri" | "rootName"> {
  let fileCount = 0;
  let dirCount = 0;
  let totalBytes = 0;
  const files: FileEntry[] = [];

  function walk(current: string) {
    let entries: fs.Dirent[];
    try {
      entries = fs.readdirSync(current, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const fullPath = path.join(current, entry.name);
      if (entry.isDirectory()) {
        dirCount++;
        walk(fullPath);
      } else if (entry.isFile()) {
        try {
          const stat = fs.statSync(fullPath);
          fileCount++;
          totalBytes += stat.size;
          files.push({ path: fullPath, bytes: stat.size });
        } catch {
          // skip unreadable files
        }
      }
    }
  }

  walk(dirPath);

  const top5Largest = files
    .sort((a, b) => b.bytes - a.bytes)
    .slice(0, 5);

  return { fileCount, dirCount, totalBytes, top5Largest };
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

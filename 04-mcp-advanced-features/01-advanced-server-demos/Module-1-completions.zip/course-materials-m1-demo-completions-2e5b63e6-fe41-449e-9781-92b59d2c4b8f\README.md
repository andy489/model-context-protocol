## Completions Demo

This demo shows how to add argument auto-complete to MCP prompts using the `completable()` helper from the MCP SDK. A `color_haiku` prompt autocompletes well-known CSS color names as the learner types, demonstrating how servers can provide dynamic completion suggestions for prompt arguments.

## Features / Skills Covered

- **`completable()` helper**: Wraps a prompt argument's Zod schema to supply dynamic completion candidates based on the current input prefix
- **Prompt argument completions**: Filtering a list of well-known CSS color names and returning matching suggestions
- **Prompt registration**: Using `server.registerPrompt()` with a multi-argument schema including an optional `mood` field

## Prerequisites

- [Node.js LTS](https://nodejs.org) (v22 or later recommended)

## Run Locally

```sh
# Install dependencies
npm install

# Start the server (stdio transport)
npm start

# Launch the MCP Inspector to explore the prompt and test completions
npm run inspect
```

## VS Code MCP Server

The `.vscode/mcp.json` file registers the following server for use in Copilot:

- **pluralsight-demo-mcp-completions**: Exposes the `color_haiku` prompt with CSS color-name autocomplete
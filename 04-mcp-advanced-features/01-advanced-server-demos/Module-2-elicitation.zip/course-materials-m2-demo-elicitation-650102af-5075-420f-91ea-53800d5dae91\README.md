## Elicitation Demo

This demo shows MCP elicitation — the ability for a server to pause a tool call mid-execution and ask the connected client for additional input before continuing. Demo 1 uses a structured form schema to collect a nickname; Demo 2 redirects the user to a URL to accept Terms of Service before the tool proceeds.

## Features / Skills Covered

- **`elicitInput`**: Pausing a tool handler to request structured input from the MCP client
- **Form-based elicitation**: Defining a Zod schema that renders as a form in a supporting MCP client
- **URL-based elicitation**: Redirecting the user to a URL (e.g., a Terms of Service page) to collect consent before a tool runs
- **Action handling**: Checking the `action` field (`accept` / `decline` / `cancel`) on the elicitation response

## Demos

| Script | File | Concept |
|--------|------|---------|
| `npm run demo1` | `src/01-form.ts` | Form-based elicitation — asks the user for a preferred nickname |
| `npm run demo2` | `src/02-url.ts` | URL-based elicitation — requires Terms of Service acceptance |

## Prerequisites

- [Node.js LTS](https://nodejs.org) (v22 or later recommended)
- [Cloudflare account](https://dash.cloudflare.com/sign-up) — required for Wrangler
- [Wrangler CLI](https://developers.cloudflare.com/workers/wrangler/install-and-update/) — authenticate once with `npx wrangler login`

## Run Locally

Install dependencies:

```sh
npm install
```

Start a demo (runs on `http://127.0.0.1:8787/mcp`):

```sh
npm run demo1
# or
npm run demo2
```

In a separate terminal, launch the MCP Inspector:

```sh
npm run inspect
```

## Deploy to Cloudflare

```sh
npm run deploy
```

## VS Code MCP Server

The `.vscode/mcp.json` file registers the following server for use in Copilot:

- **pluralsight-demo-elicitation**: Connects to the locally running server at `http://127.0.0.1:8787/mcp`

> Connect after starting `npm run demo1` or `npm run demo2`.
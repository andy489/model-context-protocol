import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";

const server = new McpServer({
  name: "Filter Demo",
  version: "1.0.0",
});

server.registerTool(
  "get_status",
  {
    description: "Get the current system status",
  },
  withLogging(async () => {
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(
            {
              status: "operational",
              environment: process.env.NODE_ENV || "development",
              timestamp: new Date().toISOString(),
            },
            null,
            2,
          ),
        },
      ],
    };
  }),
);

console.error(`MCP Server started...`);

const transport = new StdioServerTransport();
await server.connect(transport);

function withLogging(handler) {
  return async (params, extra) => {
    console.error("Handler request");
    const response = await handler(params, extra);
    console.error("Handler response");
    return response;
  };
}

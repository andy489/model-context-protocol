## Stateless Demo

This demo hosts a remote MCP server on Cloudflare using the `createMcpHandler` helper from the Agents SDK. A fresh server instance is created for every incoming HTTP request, so no state persists between client connections — a straightforward pattern for simple, horizontally-scalable tool APIs.

## Features / Skills Covered

- **`createMcpHandler`**: Wrapping a plain `McpServer` instance in a Cloudflare Workers fetch handler
- **Stateless request handling**: Creating a new server instance per request to avoid shared state between sessions
- **Remote MCP transport**: Accepting client connections over HTTP rather than stdio

## Prerequisites

- [Node.js LTS](https://nodejs.org) (v22 or later recommended)
- [Cloudflare account](https://dash.cloudflare.com/sign-up) — required for Wrangler
- [Wrangler CLI](https://developers.cloudflare.com/workers/wrangler/install-and-update/) — authenticate once with `npx wrangler login`

## Run Locally

Install dependencies:

```sh
npm install
```

Start the dev server (runs on `http://127.0.0.1:8787/mcp`):

```sh
npm start
```

Inspect with the MCP Inspector:

```sh
npm run inspect
```

## Deploy to Cloudflare

```sh
npm run deploy
```

You can use the [Cloudflare AI Playground](https://playground.ai.cloudflare.com/) to test the MCP server remotely or connect to it using MCP Inspector locally.

## Resources

- [Build a remote MCP server](https://developers.cloudflare.com/agents/guides/remote-mcp-server/)
import asyncio
import json

from fastmcp import Client
from mcp.types import TextResourceContents

async def demo_tools(client: Client) -> None:
    print("\n========== TOOLS ==========")

    # Discover what tools the server exposes
    tools = await client.list_tools()
    print(f"\nAvailable tools ({len(tools)}):")
    for tool in tools:
        print(f"  • {tool.name}: {tool.description}")

    # Submit a new proposal
    print("\n--- Calling: submit_proposal ---")
    result = await client.call_tool(
        "submit_proposal",
        {
            "title": "Observability-Driven Development",
            "speaker": "Dana Kim",
            "topic": "Developer Experience",
            "abstract": (
                "What if observability wasn't an afterthought? This talk makes the "
                "case for designing systems with telemetry as a first-class concern "
                "from day one, covering structured logging, distributed tracing, and "
                "metrics-driven iteration loops."
            ),
        },
    )
    proposal = result.data
    print(f"Submitted proposal: {proposal}")

    # Retrieve the proposal we just submitted by its ID
    print("\n--- Calling: get_proposal ---")
    result = await client.call_tool("get_proposal", {"proposal_id": proposal.id})

    fetched = result.data
    print(f"Fetched proposal: {fetched}")

    # Update its status
    print("\n--- Calling: update_proposal_status ---")
    result = await client.call_tool(
        "update_proposal_status",
        {"proposal_id": proposal.id, "status": "accepted"},
    )

    updated = result.data
    print(f"Updated proposal: {updated}")

async def main() -> None:
    print("Connecting to CFP MCP server...")
    
    client = Client("server.py")

    async with client:
        await client.ping()
        print("Connected.")
        
        await demo_tools(client)
        
if __name__ == "__main__":
    asyncio.run(main())
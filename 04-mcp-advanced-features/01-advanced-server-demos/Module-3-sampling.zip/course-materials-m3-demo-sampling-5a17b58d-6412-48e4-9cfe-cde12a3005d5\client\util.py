
import argparse
import json
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

DEFAULT_SERVER_URL = "http://127.0.0.1:8787/mcp"
DEFAULT_MODEL = "claude-sonnet-4-5"

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run a FastMCP client against the local sampling demo server.",
    )
    parser.add_argument(
        "mode",
        choices=["probe", "plan"],
        help="Client mode to run.",
    )
    parser.add_argument(
        "--server-url",
        default=DEFAULT_SERVER_URL,
        help=f"MCP server URL. Defaults to {DEFAULT_SERVER_URL}.",
    )
    parser.add_argument(
        "--destination",
        default="tokyo",
        help="Destination passed to plan_trip.",
    )
    parser.add_argument(
        "--days",
        default=2,
        type=int,
        help="Number of days passed to plan_trip.",
    )
    parser.add_argument(
        "--model",
        default=DEFAULT_MODEL,
        help=f"Anthropic model to use in plan mode. Defaults to {DEFAULT_MODEL}.",
    )
    return parser



def load_local_env() -> None:
    """Load environment variables from local .env files if present."""
    client_dir = Path(__file__).resolve().parent
    project_root = client_dir.parent

    # Prefer client-local secrets, then fall back to a repo-level .env if present.
    load_dotenv(client_dir / ".env", override=False)
    load_dotenv(project_root / ".env", override=False)

def extract_text_blocks(content: Any) -> list[str]:
    """Extract text strings from MCP message content objects."""
    if content is None:
        return []

    if isinstance(content, str):
        return [content]

    if isinstance(content, list):
        blocks: list[str] = []
        for item in content:
            blocks.extend(extract_text_blocks(item))
        return blocks

    annotations = getattr(content, "annotations", None)
    audience = getattr(annotations, "audience", None) if annotations is not None else None
    if isinstance(audience, list) and "assistant" in audience:
        return []

    text = getattr(content, "text", None)
    if isinstance(text, str):
        return [text]

    nested_content = getattr(content, "content", None)
    if nested_content is not None:
        return extract_text_blocks(nested_content)

    return []


def unwrap_result(result: Any) -> Any:
    """Return the most useful payload from a FastMCP tool result."""
    for attribute in ("data", "structuredContent", "structured_content", "content"):
        value = getattr(result, attribute, None)
        if value is not None:
            return value
    return result


def format_payload(payload: Any) -> str:
    """Convert FastMCP/MCP payloads into readable console output."""
    if isinstance(payload, str):
        return payload

    text_blocks = extract_text_blocks(payload)
    if text_blocks:
        return "\n".join(text_blocks)

    if hasattr(payload, "model_dump"):
        return json.dumps(payload.model_dump(), indent=2)

    if isinstance(payload, list):
        normalized = [
            item.model_dump() if hasattr(item, "model_dump") else item
            for item in payload
        ]
        return json.dumps(normalized, indent=2, default=str)

    if isinstance(payload, dict):
        return json.dumps(payload, indent=2, default=str)

    return str(payload)

## Notifications Demos

These demos show how MCP servers send MCP notifications to connected clients.
They are implemented in Python using both [FastMCP](https://gofastmcp.com) and with TypeScript because
not all SDKs supported every notification use case equally.

## Features / Skills Covered

- **`notifications/tools/list_changed`**: Dynamically enabling and disabling tools at runtime so clients always see an up-to-date tool list
- **`notifications/resources/updated`**: Pushing a notification to clients when a resource's content has changed
- **`notifications/progress`**: Streaming incremental progress updates during a long-running tool call via `ctx.report_progress()`
- **FastMCP tags**: Using `tags` to group tools and bulk-disable them at runtime

## Demos

| File                         | Notification                       | Concept                                                |
| ---------------------------- | ---------------------------------- | ------------------------------------------------------ |
| `src/01_list_changed.py`     | `notifications/tools/list_changed` | Dynamically disable tools at runtime                   |
| `src/02_resource_updated.ts` | `notifications/resources/updated`  | Notify clients a resource's content changed            |
| `src/03_progress.py`         | `notifications/progress`           | Stream incremental progress during a long-running tool |

## Run Locally

You will need Node.js 24+, Python 3.11+ and a virtual environment with `fastmcp` installed.

```sh
# Create and activate a virtual environment (first time only)
python -m venv .venv
.venv\Scripts\activate        # Windows
source .venv/bin/activate     # macOS / Linux

# Install dependencies
pip install -r requirements.txt
npm install

# Run a demo directly
npm run demo1
npm run demo2
npm run demo3

# Or launch MCP Inspector against a specific demo
npm run inspect1
npm run inspect2
npm run inspect3
```

## VS Code MCP Servers

The `.vscode/mcp.json` file registers all three servers so you can connect to
them directly from GitHub Copilot or any VS Code MCP client:

- **pluralsight-demo-mcp-notifications-list-changed** — Demo 1
- **pluralsight-demo-mcp-notifications-resource-updated** — Demo 2
- **pluralsight-demo-mcp-notifications-progress** — Demo 3

The servers reuse the virtual environment from `m2-demo-sampling`.

## Note: MCP Inspector Patches

This demo includes a patch that applies [the PR #1132](https://github.com/modelcontextprotocol/inspector/pull/1132) and [PR 1148](https://github.com/modelcontextprotocol/inspector/pull/1148) to the inspector, which adds support for `list_changed` notifications and fixing the resource refresh button.

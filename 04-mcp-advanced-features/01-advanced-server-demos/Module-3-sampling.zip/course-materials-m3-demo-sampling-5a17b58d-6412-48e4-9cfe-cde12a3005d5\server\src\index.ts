import { McpServer, ToolCallback } from "@modelcontextprotocol/sdk/server/mcp.js";
import {
  ContentBlock,
	CreateMessageRequestParamsWithTools,
	CreateMessageResultWithTools,
} from "@modelcontextprotocol/sdk/types.js";
import { McpAgent } from "agents/mcp";
import { z } from "zod";

export class MyMCP extends McpAgent {
	server = new McpServer({
		name: "Trip Planner MCP Server",
		version: "1.0.0",
	});

	async init() {
		this.server.registerTool(
			"plan_trip",
			{
				description: "Plans a trip itinerary using curated local recommendations",
				inputSchema: z.object({
					destination: z.string().describe("City to visit (e.g. tokyo, lisbon)"),
					days: z.number().describe("Number of days"),
				}),
			},
			async ({ destination, days }, extra) => {
				const placeIds = DESTINATION_DATA[destination.toLowerCase()];

				if (!placeIds) {
					return {
						content: [
							{
								type: "text",
								text: `No recommendations found for ${destination}.`,
							},
						],
					};
				}

				// Store the sampling request parameters in a variable to reuse for both the initial sampling call and potential follow-up messages after tool usage
				const samplingRequest: CreateMessageRequestParamsWithTools = {
					maxTokens: 512,
					toolChoice: {
						mode: "required",
					},
					messages: [
						{
							role: "user",
							content: {
								type: "text",
								text: `Create a ${days}-day itinerary for ${destination} using ONLY these curated spots:
${placeIds
	.map((placeId, index) => {
		const details = PLACE_DETAILS_DATA[placeId];
		const label = details?.name ?? placeId;
		return `${index + 1}. ${label} (ID: ${placeId})`;
	})
	.join("\n")}

Spread them across the ${days} days naturally. Use the get_place_details tool to enrich the itinerary with details about each spot by passing its ID, not its display name.
When generating the itinerary, include the opening hours and address so the user knowns when and where they can visit. 
Be concise.`,
							},
						},
					],
					tools: [
						{
							name: "get_place_details",
							inputSchema: {
								type: "object",
								properties: {
									placeId: {
										type: "string",
										description: "Stable ID of the place to get details for",
									},
								},
								required: ["placeId"],
							},
						},
					],
				};

				// Here's the Sampling call -- server asking the client's LLM to do the synthesis and enrich via tool calling
				const initialSamplingResult: CreateMessageResultWithTools =
					await this.server.server.createMessage(samplingRequest);

				// Get the tool usage the server should perform based on the LLM's response
				const toolUsageList = Array.isArray(initialSamplingResult.content)
					? initialSamplingResult.content.filter((c) => c.type === "tool_use")
					: initialSamplingResult.content.type === "tool_use"
						? [initialSamplingResult.content]
						: [];

				console.info(`LLM requested ${toolUsageList.length} tool calls`);

				const toolResults: Array<{
					toolUseId: string;
          content: ContentBlock[];
					details?: z.infer<typeof PlaceDetailsOutputSchema>["details"];
				}> = [];

				// For each tool usage, call the corresponding tool function and store a matching
				// tool_result payload. The follow-up message must include a result for every
				// preceding tool_use id in the same order.
				for (const toolUsage of toolUsageList) {
					if (toolUsage.name === "get_place_details") {
						const input = toolUsage.input as z.infer<typeof PlaceDetailsInputSchema>;
						const detailsResult = await this.getPlaceDetailsTool(
							{ placeId: input.placeId.toLowerCase() },
							extra,
						);

						const output = detailsResult.structuredContent as z.infer<
							typeof PlaceDetailsOutputSchema
						>;

						if (output.details) {
							console.info(
								`Tool call for place ID "${input.placeId}" returned details`,
							);
						} else {
							console.warn(
								`Tool call for place ID "${input.placeId}" did not return any details`,
							);
						}

						toolResults.push({
							toolUseId: toolUsage.id,
              content: detailsResult.content,
							details: output.details,
						});
					}
				}

				// After performing the necessary tool calls, we can make a follow-up Sampling call to synthesize the
				// final itinerary enriched with the tool results. We pass the tool results back to the LLM as part of
				// the message content so it can use that information to generate a more detailed itinerary.
				const samplingWithToolsResult = await this.server.server.createMessage({
					maxTokens: samplingRequest.maxTokens * 2,
					messages: [
						...samplingRequest.messages,
						{
							role: "assistant",
							content: Array.isArray(initialSamplingResult.content)
								? initialSamplingResult.content
								: [initialSamplingResult.content],
						},
						{
							role: "user",
							content: [
								...toolResults.map(({ toolUseId, content, details }) => ({
									type: "tool_result" as const,
									toolUseId,
									content,
                  structuredContent: { details: details ?? undefined },
								})),
							],
						},
					],
				});

				// The final itinerary generated by the LLM after having access to the tool results
				const itinerary =
					samplingWithToolsResult.content.type === "text"
						? samplingWithToolsResult.content.text
						: "Could not generate itinerary.";

				return {
					content: [
						{
							type: "text",
							text: itinerary,
						},

						// Ask the LLM to echo the itinerary back to the user without modification or additional synthesis
						{
							type: "text",
							text: "Do not summarize or modify the itinerary. Echo it back to the user directly.",
							annotations: { audience: ["assistant"] },
						},
					],
				};
			},
		);

		// In order to call the logic for the tool from the server, the callback is defined as a method on the class
		// and passed to registerTool. This allows the server to execute this function when the LLM indicates it wants to use the tool,
		// and also allows us to reuse this logic if we want to call it directly from our main tool function
		// (e.g. to get details for all spots at once instead of making the LLM call the tool multiple times).
		this.server.registerTool(
			"get_place_details",
			{
				description: "Gets details about a specific place",
				inputSchema: PlaceDetailsInputSchema,
				outputSchema: PlaceDetailsOutputSchema,
			},
			this.getPlaceDetailsTool.bind(this),
		);
	}

	getPlaceDetailsTool: ToolCallback<typeof PlaceDetailsInputSchema> = ({ placeId }) => {
		const details = PLACE_DETAILS_DATA[placeId];
		if (!details) {
			return {
				content: [{ type: "text", text: `No details found for place ID ${placeId}.` }],
				structuredContent: {
					details: undefined,
				},
			};
		}

		// In a real implementation, you'd fetch real details here. For demo, we'll return dummy data.

		return {
			content: [
				{
					type: "text",
					text: `Details for ${details.name} (${placeId}): ${JSON.stringify(details, null, 2)}`,
				},
			],
			structuredContent: {
				details,
			},
		};
	};
}

export default MyMCP.serve("/mcp");


const PlaceDetailsOutputSchema = z.object({
	details: z
		.object({
			id: z.string(),
			name: z.string(),
			description: z.string(),
			openingHours: z.string(),
			address: z.string(),
		})
		.optional()
		.describe(
			"Details about the place, including name, description, opening hours, and address",
		),
});

const PlaceDetailsInputSchema = z.object({
	placeId: z.string().describe("Stable ID of the place to get details for"),
});

// The server's "owned" data -- this might be proprietary info, or
// just data that's easier to maintain on the server side.
// The key is that the LLM doesn't have direct access to this data,
// and must rely on the server's tool function to use it.
const DESTINATION_DATA: Record<string, string[]> = {
	tokyo: [
		"tokyo_tsukiji_outer_market",
		"tokyo_teamlab_borderless",
		"tokyo_golden_gai",
		"tokyo_yanaka",
	],
	lisbon: [
		"lisbon_lx_factory",
		"lisbon_time_out_market",
		"lisbon_pena_palace",
		"lisbon_pasteis_de_belem",
	],
};

// Additional data for the get_place_details tool
const PLACE_DETAILS_DATA: Record<string, z.infer<typeof PlaceDetailsOutputSchema>["details"]> = {
	tokyo_tsukiji_outer_market: {
		id: "tokyo_tsukiji_outer_market",
		openingHours: "5am - 2pm",
		address: "5 Chome-2-1 Tsukiji, Chuo City, Tokyo 104-0045, Japan",
		description: "A bustling market known for fresh sushi and seafood.",
		name: "Tsukiji Outer Market",
	},
	tokyo_teamlab_borderless: {
		id: "tokyo_teamlab_borderless",
		openingHours: "10am - 7pm",
		address: "1 Chome-3-8 Aomi, Koto City, Tokyo 135-0064, Japan",
		description: "An immersive digital art museum with interactive exhibits.",
		name: "teamLab Borderless",
	},
	tokyo_golden_gai: {
		id: "tokyo_golden_gai",
		openingHours: "6pm - 4am",
		address: "1 Chome-1 Kabukicho, Shinjuku City, Tokyo 160-0021, Japan",
		description: "A famous area with narrow alleys filled with tiny bars.",
		name: "Golden Gai",
	},
	tokyo_yanaka: {
		id: "tokyo_yanaka",
		openingHours: "Open 24 hours",
		address: "Yanaka, Taito City, Tokyo 110-0001, Japan",
		description: "A charming neighborhood that retains the atmosphere of old Tokyo.",
		name: "Yanaka",
	},
	lisbon_lx_factory: {
		id: "lisbon_lx_factory",
		openingHours: "10am - 8pm (Sundays)",
		address: "R. Rodrigues de Faria 103, 1300-501 Lisboa, Portugal",
		description: "A trendy market with local crafts, food, and music.",
		name: "LX Factory Sunday Market",
	},
	lisbon_time_out_market: {
		id: "lisbon_time_out_market",
		openingHours: "10am - 12am",
		address: "Av. 24 de Julho 49, 1200-479 Lisboa, Portugal",
		description: "A vibrant food hall featuring the best of Lisbon's culinary scene.",
		name: "Time Out Market",
	},
	lisbon_pena_palace: {
		id: "lisbon_pena_palace",
		openingHours: "9:30am - 6:30pm",
		address: "Estrada da Pena, Sintra, Portugal",
		description: "A romantic palace perched on a hilltop with stunning views.",
		name: "Pena Palace",
	},
	lisbon_pasteis_de_belem: {
		id: "lisbon_pasteis_de_belem",
		openingHours: "8am - 11pm",
		address: "Rua de Belém 84-92, 1300-085 Lisboa, Portugal",
		description: "The iconic bakery known for its delicious custard tarts.",
		name: "Pastéis de Belém",
	},
};

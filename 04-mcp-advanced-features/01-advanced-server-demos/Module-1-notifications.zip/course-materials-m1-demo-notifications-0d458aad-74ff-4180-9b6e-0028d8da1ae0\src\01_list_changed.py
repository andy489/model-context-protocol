"""
Demo 1 — Tool List Changed Notification

Shows how FastMCP automatically sends a `notifications/tools/list_changed`
notification to connected clients whenever tools are added, removed, enabled,
or disabled at runtime.
"""

from fastmcp import FastMCP, Context
from mcp.types import ToolAnnotations

mcp = FastMCP(name="Notifications Demo")


@mcp.tool(
    description="Restart the server",
    tags={"admin"},
    annotations=ToolAnnotations(destructiveHint=True),
)
def restart_server(server_id: str) -> str:
    """Restart a managed server by ID."""
    return f"Restarting server {server_id}..."


@mcp.tool(
    description="Get the current server status",
    annotations=ToolAnnotations(readOnlyHint=True),
)
def get_server_status(server_id: str) -> str:
    """Returns the current running status of a server."""
    return f"Server {server_id} is running"


@mcp.tool(
    description="Delete a server",
    tags={"admin"},
    annotations=ToolAnnotations(destructiveHint=True),
)
def delete_server(server_id: str) -> str:
    """Permanently delete a managed server by ID."""
    return f"Deleting server {server_id}..."


@mcp.tool(description="Modify admin settings")
async def modify_admin_settings(ctx: Context) -> str:
    """
    Modifies admin settings and disables all admin-tagged tools.

    After this call, `restart_server` and `delete_server` will no longer
    appear in the tool list. FastMCP automatically sends a
    `notifications/tools/list_changed` notification — no manual call needed.
    """
    # Disable all tools tagged as "admin".
    # This disables it for the whole server
    # This does not send a notification to clients
    # See: https://gofastmcp.com/servers/visibility#disabling-components
    # mcp.disable(tags={"admin"})

    # Per-session visibility
    # This automatically sends list_changed notifications to the client.
    # See: https://gofastmcp.com/servers/visibility#per-session-visibility
    await ctx.disable_components(tags={"admin"})

    return "Modified admin settings. Admin tools have been disabled."


if __name__ == "__main__":
    mcp.run()

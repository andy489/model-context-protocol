import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  RootsListChangedNotificationSchema,
  type Root,
} from "@modelcontextprotocol/sdk/types.js";

const server = new McpServer({
  name: "Root Change Tracker",
  version: "1.0.0",
});

let roots: Root[] = [];
let lastUpdated: string = "";

server.server.oninitialized = async () => {
  const caps = server.server.getClientCapabilities();

  if (!caps?.roots) {
    console.error("Client does not support roots. describe-scope will show no roots.");
    return;
  }

  await fetchAndStoreRoots();

  if (caps.roots.listChanged) {
    server.server.setNotificationHandler(
      RootsListChangedNotificationSchema,
      async () => {
        console.error("Received roots/list_changed — re-fetching roots...");
        await fetchAndStoreRoots();

        // Notify the client that tools may reflect new state
        await server.server.notification({
          method: "notifications/tools/list_changed",
          params: {},
        });
      },
    );
    console.error("Subscribed to roots/list_changed notifications.");
  } else {
    console.error("Client does not send roots/list_changed notifications. Roots will not update after init.");
  }
};

async function fetchAndStoreRoots() {
  const result = await server.server.listRoots();
  roots = result.roots;
  lastUpdated = new Date().toISOString();
  console.error(`Roots updated at ${lastUpdated}: ${roots.length} root(s).`);
}

server.registerTool(
  "describe-scope",
  {
    description:
      "Returns the current set of client-declared roots and when the server last received them. Call this before and after changing roots in your client to observe the server reacting to roots/list_changed notifications.",
  },
  async () => {
    if (roots.length === 0) {
      return {
        content: [
          {
            type: "text",
            text: lastUpdated
              ? `No roots declared by the client (last checked: ${lastUpdated}).`
              : "No roots have been received yet.",
          },
        ],
      };
    }

    const lines: string[] = [
      `Last updated: ${lastUpdated}`,
      `Roots (${roots.length}):`,
      "",
    ];

    for (const root of roots) {
      lines.push(`  - ${root.name ?? "(unnamed)"}`);
      lines.push(`    URI: ${root.uri}`);
    }

    return {
      content: [{ type: "text", text: lines.join("\n") }],
    };
  },
);

const transport = new StdioServerTransport();
await server.connect(transport);


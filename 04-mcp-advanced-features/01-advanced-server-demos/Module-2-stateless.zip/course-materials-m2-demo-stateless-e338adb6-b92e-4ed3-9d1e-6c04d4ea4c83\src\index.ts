import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { createMcpHandler } from "agents/mcp";
import { z } from "zod";

function createServer() {
  const server = new McpServer({
    name: "Hello MCP Server",
    version: "1.0.0",
  });

  server.registerTool(
    "hello",
    { 
      description: "Returns a greeting message",
      inputSchema: { name: z.string().optional() }
    },
    async ({ name }, extra) => {
      return {
        content: [
          {
            text: `Hello, ${name ?? "World"}!`,
            type: "text",
          },
          {
            text: `Session ID: ${extra.sessionId}`,
            type: "text",
          },
        ],
      };
    },
  );

  return server;
}

export default {
  fetch: async (request: Request, env: Env, ctx: ExecutionContext) => {
    // Create new server instance per request
    const server = createServer();
    const handler = createMcpHandler(server);
    
    return handler(request, env, ctx);
  },
} satisfies ExportedHandler<Env>;
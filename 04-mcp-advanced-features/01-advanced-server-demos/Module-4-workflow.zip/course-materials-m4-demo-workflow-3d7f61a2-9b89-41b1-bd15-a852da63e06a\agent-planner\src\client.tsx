import { Suspense, useCallback, useState, useEffect, useRef } from "react";
import { useAgent } from "agents/react";
import { useAgentChat } from "@cloudflare/ai-chat/react";
import { isToolUIPart, getToolName } from "ai";
import type { UIMessage } from "ai";
import type { MCPServersState } from "agents";
import {
  Button,
  Badge,
  InputArea,
  Empty,
  Surface,
  Text,
  PoweredByCloudflare
} from "@cloudflare/kumo";
import {
  PaperPlaneRightIcon,
  StopIcon,
  TrashIcon,
  CheckCircleIcon,
  XCircleIcon,
  GearIcon,
  CloudSunIcon,
  PlugsConnectedIcon,
  CaretDownIcon,
  SignInIcon,
  XIcon,
  WrenchIcon,
  MoonIcon,
  SunIcon,
  AirplaneIcon,
  ArrowClockwiseIcon
} from "@phosphor-icons/react";

type ConnectionStatus = "connecting" | "connected" | "disconnected";
type Progress = { message: string; percent: number };

function ConnectionIndicator({ status }: { status: ConnectionStatus }) {
  const dot =
    status === "connected"
      ? "bg-green-500"
      : status === "connecting"
        ? "bg-yellow-500"
        : "bg-red-500";
  const text =
    status === "connected"
      ? "text-kumo-success"
      : status === "connecting"
        ? "text-kumo-warning"
        : "text-kumo-danger";
  const label =
    status === "connected"
      ? "Connected"
      : status === "connecting"
        ? "Connecting..."
        : "Disconnected";
  return (
    <div className="flex items-center gap-2" role="status">
      <span className={`size-2 rounded-full ${dot}`} />
      <span className={`text-xs ${text}`}>{label}</span>
    </div>
  );
}

function ModeToggle() {
  const [mode, setMode] = useState(
    () => localStorage.getItem("theme") || "light"
  );

  useEffect(() => {
    document.documentElement.setAttribute("data-mode", mode);
    document.documentElement.style.colorScheme = mode;
    localStorage.setItem("theme", mode);
  }, [mode]);

  return (
    <Button
      variant="ghost"
      shape="square"
      aria-label="Toggle theme"
      onClick={() => setMode((m) => (m === "light" ? "dark" : "light"))}
      icon={mode === "light" ? <MoonIcon size={16} /> : <SunIcon size={16} />}
    />
  );
}

type FlightSearchStatus = {
  status: string;
  output?: unknown;
  error?: string;
} | null;

function FlightSearchPanel() {
  const [isOpen, setIsOpen] = useState(false);
  const [task, setTask] = useState("");
  const [instanceId, setInstanceId] = useState("");
  const [isStarting, setIsStarting] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [startResult, setStartResult] = useState<{ instanceId: string } | null>(null);
  const [statusResult, setStatusResult] = useState<FlightSearchStatus>(null);
  const [startError, setStartError] = useState<string | null>(null);
  const [statusError, setStatusError] = useState<string | null>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    function handleClickOutside(e: MouseEvent) {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [isOpen]);

  const handleStart = async () => {
    if (!task.trim()) return;
    setIsStarting(true);
    setStartError(null);
    setStartResult(null);
    try {
      const res = await fetch("/agents/flight-search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ task: task.trim() }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as { instanceId: string };
      setStartResult(data);
      setInstanceId(data.instanceId);
    } catch (e) {
      setStartError(e instanceof Error ? e.message : "Unknown error");
    } finally {
      setIsStarting(false);
    }
  };

  const handleStatus = async () => {
    if (!instanceId.trim()) return;
    setIsChecking(true);
    setStatusError(null);
    setStatusResult(null);
    try {
      const params = new URLSearchParams({ instanceId: instanceId.trim() });
      const res = await fetch(`/agents/flight-search/status?${params}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as FlightSearchStatus;
      setStatusResult(data);
    } catch (e) {
      setStatusError(e instanceof Error ? e.message : "Unknown error");
    } finally {
      setIsChecking(false);
    }
  };

  return (
    <div className="relative" ref={panelRef}>
      <Button
        variant="secondary"
        icon={<AirplaneIcon size={16} />}
        onClick={() => setIsOpen(!isOpen)}
      >
        Flight Search
        {startResult && (
          <Badge variant="primary" className="ml-1.5">1</Badge>
        )}
      </Button>

      {isOpen && (
        <div className="absolute right-0 top-full mt-2 w-96 z-50">
          <Surface className="rounded-xl ring ring-kumo-line shadow-lg p-4 space-y-4">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AirplaneIcon size={16} className="text-kumo-accent" />
                <Text size="sm" bold>Flight Search</Text>
              </div>
              <Button
                variant="ghost"
                size="sm"
                shape="square"
                aria-label="Close flight search panel"
                icon={<XIcon size={14} />}
                onClick={() => setIsOpen(false)}
              />
            </div>

            {/* Start workflow */}
            <div className="space-y-2">
              <Text size="xs" variant="secondary" bold>Start Workflow</Text>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={task}
                  onChange={(e) => setTask(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") handleStart(); }}
                  placeholder="e.g. Get next flight for user"
                  className="flex-1 px-3 py-1.5 text-sm rounded-lg border border-kumo-line bg-kumo-base text-kumo-default placeholder:text-kumo-inactive focus:outline-none focus:ring-1 focus:ring-kumo-accent"
                />
                <Button
                  variant="primary"
                  size="sm"
                  icon={<AirplaneIcon size={14} />}
                  disabled={isStarting || !task.trim()}
                  onClick={handleStart}
                >
                  {isStarting ? "..." : "Start"}
                </Button>
              </div>
              {startError && (
                <p className="text-xs text-red-500">{startError}</p>
              )}
              {startResult && (
                <div className="p-2 rounded-lg bg-kumo-elevated">
                  <span className="text-[10px] uppercase tracking-wider text-kumo-inactive font-semibold">Instance ID</span>
                  <p className="mt-0.5 text-xs font-mono text-kumo-subtle break-all">{startResult.instanceId}</p>
                </div>
              )}
            </div>

            {/* Check status */}
            <div className="space-y-2 pt-2 border-t border-kumo-line">
              <Text size="xs" variant="secondary" bold>Check Status</Text>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={instanceId}
                  onChange={(e) => setInstanceId(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") handleStatus(); }}
                  placeholder="Instance ID"
                  className="flex-1 px-3 py-1.5 text-sm rounded-lg border border-kumo-line bg-kumo-base text-kumo-default placeholder:text-kumo-inactive focus:outline-none focus:ring-1 focus:ring-kumo-accent font-mono"
                />
                <Button
                  variant="secondary"
                  size="sm"
                  icon={<ArrowClockwiseIcon size={14} className={isChecking ? "animate-spin" : ""} />}
                  disabled={isChecking || !instanceId.trim()}
                  onClick={handleStatus}
                >
                  {isChecking ? "..." : "Check"}
                </Button>
              </div>
              {statusError && (
                <p className="text-xs text-red-500">{statusError}</p>
              )}
              {statusResult !== null && (
                <pre className="p-2 rounded-lg bg-kumo-elevated text-xs font-mono text-kumo-subtle overflow-x-auto max-h-48 overflow-y-auto whitespace-pre-wrap break-all">
                  {JSON.stringify(statusResult, null, 2)}
                </pre>
              )}
            </div>
          </Surface>
        </div>
      )}
    </div>
  );
}

function ProgressPanel({ progress, tool }: { progress: Progress | null; tool: string | null }) {
  const [lastProgress, setLastProgress] = useState<Progress | null>(null);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    if (progress !== null) {
      setLastProgress(progress);
      setDismissed(false);
    }
  }, [progress]);

  const shownProgress = progress ?? lastProgress;
  const percent = shownProgress ? Math.round(shownProgress.percent * 100) : 0;
  const isVisible = progress !== null && !dismissed;
  const isComplete = !!shownProgress && shownProgress.percent >= 1;

  return (
    <div className="fixed right-0 top-1/2 -translate-y-1/2 z-50 pointer-events-none">
      <div
        className="transition-transform duration-300 ease-out pointer-events-auto"
        style={{ transform: isVisible ? "translateX(0%)" : "translateX(110%)" }}
      >
        <Surface className="w-72 mr-4 p-4 rounded-xl shadow-2xl ring ring-kumo-line">
          <div className="flex items-center gap-2 mb-3">
            {isComplete ? (
              <CheckCircleIcon size={16} className="text-kumo-success" />
            ) : (
              <GearIcon size={16} className="text-kumo-accent animate-spin" />
            )}
            <Text size="sm" bold>
              {isComplete ? "Complete" : "Running Workflow"}
            </Text>
            <span className="ml-auto text-xs font-mono font-medium text-kumo-subtle">
              {percent}%
            </span>
            {isComplete && (
              <Button
                variant="ghost"
                size="sm"
                shape="square"
                aria-label="Dismiss"
                icon={<XIcon size={12} />}
                onClick={() => setDismissed(true)}
              />
            )}
          </div>
          {shownProgress && (
            <p className="text-sm text-kumo-strong mb-3 leading-relaxed">
              {shownProgress.message}
            </p>
          )}
          {tool && (
            <p className="text-xs text-kumo-subtle mb-3 leading-relaxed">
              {`Running tool: ${tool}`}
            </p>
          )}
          <div className="relative h-1.5 w-full rounded-full bg-kumo-line overflow-hidden">
            <div
              className={`absolute inset-y-0 left-0 rounded-full transition-all duration-500 ease-out ${
                isComplete ? "bg-green-500" : "bg-kumo-brand"
              }`}
              style={{ width: `${percent}%` }}
            />
          </div>
        </Surface>
      </div>
    </div>
  );
}

function SystemMessage({ message }: { message: UIMessage }) {
  const [expanded, setExpanded] = useState(false);
  const text = getMessageText(message);
  return (
    <div className="relative flex justify-center">
      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        className="group flex items-center gap-1.5 text-[10px] uppercase tracking-wider font-semibold text-kumo-inactive hover:text-kumo-subtle transition-colors"
      >
        <GearIcon size={11} />
        System message
        <span className="transition-transform duration-200" style={{ display: "inline-block", transform: expanded ? "rotate(180deg)" : "rotate(0deg)" }}>
          <CaretDownIcon weight="fill" />
        </span>
      </button>
      {expanded && (
        <div className="absolute mt-5 z-10 max-w-lg">
          <Surface className="px-4 py-3 rounded-xl ring ring-kumo-line shadow-lg">
            <p className="text-xs font-mono text-kumo-subtle whitespace-pre-wrap wrap-break-word">{text}</p>
          </Surface>
        </div>
      )}
    </div>
  );
}

function getMessageText(message: UIMessage): string {
  return message.parts
    .filter((part) => part.type === "text")
    .map((part) => (part as { type: "text"; text: string }).text)
    .join("");
}

function formatToolOutput(
  output: unknown
): string {
  if (typeof output === "string") {
    return output;
  }

  return JSON.stringify(output, null, 2);
}

function Chat() {
  const [progress, setProgress] = useState<Progress | null>(null);
  const [progressToolCall, setProgressToolCall] = useState<string | null>(null);
  const [connectionStatus, setConnectionStatus] =
    useState<ConnectionStatus>("connecting");
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [mcpState, setMcpState] = useState<MCPServersState>({
    prompts: [],
    resources: [],
    servers: {},
    tools: []
  });
  const [showMcpPanel, setShowMcpPanel] = useState(false);
  const [mcpName, setMcpName] = useState("");
  const [mcpUrl, setMcpUrl] = useState("");
  const [isAddingServer, setIsAddingServer] = useState(false);
  const mcpPanelRef = useRef<HTMLDivElement>(null);

  const agent = useAgent({
    agent: "TripPlannerAgent",
    onMessage: (message) => {
      const data = JSON.parse(message.data);
      if (data.type === "progress") {
        setProgress(data.progress);
        setProgressToolCall(null);
      } else if (data.type === "complete") {
        setProgress({ message: data.result.message, percent: 1 });
      } else if (data.type === "error") {
        setProgress({ message: data.error, percent: 1 });
      } else if (data.type === "tool_call") {
        setProgressToolCall(data.tool);
      }
    },
    onOpen: useCallback(() => setConnectionStatus("connected"), []),
    onClose: useCallback(() => setConnectionStatus("disconnected"), []),
    onError: useCallback(
      (error: Event) => console.error("WebSocket error:", error),
      []
    ),
    onMcpUpdate: useCallback((state: MCPServersState) => {
      setMcpState(state);
    }, [])
  });

  // Close MCP panel when clicking outside
  useEffect(() => {
    if (!showMcpPanel) return;
    function handleClickOutside(e: MouseEvent) {
      if (
        mcpPanelRef.current &&
        !mcpPanelRef.current.contains(e.target as Node)
      ) {
        setShowMcpPanel(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [showMcpPanel]);

  const handleAddServer = async () => {
    if (!mcpName.trim() || !mcpUrl.trim()) return;
    setIsAddingServer(true);
    try {
      await agent.call("addServer", [mcpName.trim(), mcpUrl.trim()]);
      setMcpName("");
      setMcpUrl("");
    } catch (e) {
      console.error("Failed to add MCP server:", e);
    } finally {
      setIsAddingServer(false);
    }
  };

  const handleRemoveServer = async (serverId: string) => {
    try {
      await agent.call("removeServer", [serverId]);
    } catch (e) {
      console.error("Failed to remove MCP server:", e);
    }
  };

  const serverEntries = Object.entries(mcpState.servers);
  const mcpToolCount = mcpState.tools.length;

  const {
    messages,
    sendMessage,
    clearHistory,
    addToolApprovalResponse,
    stop,
    isStreaming
  } = useAgentChat({
    agent,
    // Custom data sent with every request (available in options.body on server)
    body: {
      clientVersion: "1.0.0"
    },
    // Handle client-side tools (tools without server execute function)
    onToolCall: async ({ toolCall, addToolOutput }) => {
      if (toolCall.toolName === "getUserTimezone") {
        addToolOutput({
          toolCallId: toolCall.toolCallId,
          output: {
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            localTime: new Date().toLocaleTimeString()
          }
        });
      }
    }
  });

  const isConnected = connectionStatus === "connected";

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const send = useCallback(() => {
    const text = input.trim();
    if (!text || isStreaming) return;
    setInput("");
    sendMessage({ role: "user", parts: [{ type: "text", text }] });
  }, [input, isStreaming, sendMessage]);

  return (
    <div className="flex flex-col h-screen bg-kumo-elevated">
      {/* Header */}
      <header className="px-5 py-4 bg-kumo-base border-b border-kumo-line">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h1 className="text-lg font-semibold text-kumo-default">Travel Agent</h1>
            <Badge variant="secondary">
              <CloudSunIcon size={12} weight="bold" className="mr-1" />
              Workflows and MCP
            </Badge>
          </div>
          <div className="flex items-center gap-3">
            <ConnectionIndicator status={connectionStatus} />
            <ModeToggle />
            <FlightSearchPanel />
            <div className="relative" ref={mcpPanelRef}>
              <Button
                variant="secondary"
                icon={<PlugsConnectedIcon size={16} />}
                onClick={() => setShowMcpPanel(!showMcpPanel)}
              >
                MCP
                {mcpToolCount > 0 && (
                  <Badge variant="primary" className="ml-1.5">
                    <WrenchIcon size={10} className="mr-0.5" />
                    {mcpToolCount}
                  </Badge>
                )}
              </Button>

              {/* MCP Dropdown Panel */}
              {showMcpPanel && (
                <div className="absolute right-0 top-full mt-2 w-96 z-50">
                  <Surface className="rounded-xl ring ring-kumo-line shadow-lg p-4 space-y-4">
                    {/* Panel Header */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <PlugsConnectedIcon
                          size={16}
                          className="text-kumo-accent"
                        />
                        <Text size="sm" bold>
                          MCP Servers
                        </Text>
                        {serverEntries.length > 0 && (
                          <Badge variant="secondary">
                            {serverEntries.length}
                          </Badge>
                        )}
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        shape="square"
                        aria-label="Close MCP panel"
                        icon={<XIcon size={14} />}
                        onClick={() => setShowMcpPanel(false)}
                      />
                    </div>

                    {/* Server List */}
                    {serverEntries.length > 0 && (
                      <div className="space-y-2 max-h-60 overflow-y-auto">
                        {serverEntries.map(([id, server]) => (
                          <div
                            key={id}
                            className="flex items-start justify-between p-2.5 rounded-lg border border-kumo-line"
                          >
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2">
                                <span className="text-sm font-medium text-kumo-default truncate">
                                  {server.name}
                                </span>
                                <Badge
                                  variant={
                                    server.state === "ready"
                                      ? "primary"
                                      : server.state === "failed"
                                        ? "destructive"
                                        : "secondary"
                                  }
                                >
                                  {server.state}
                                </Badge>
                              </div>
                              <span className="text-xs font-mono text-kumo-subtle truncate block mt-0.5">
                                {server.server_url}
                              </span>
                              {server.state === "failed" && server.error && (
                                <span className="text-xs text-red-500 block mt-0.5">
                                  {server.error}
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-1 shrink-0 ml-2">
                              {server.state === "authenticating" &&
                                server.auth_url && (
                                  <Button
                                    variant="primary"
                                    size="sm"
                                    icon={<SignInIcon size={12} />}
                                    onClick={() =>
                                      window.open(
                                        server.auth_url as string,
                                        "oauth",
                                        "width=600,height=800"
                                      )
                                    }
                                  >
                                    Auth
                                  </Button>
                                )}
                              
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Tool Summary */}
                    {mcpToolCount > 0 && (
                      <div className="pt-2 border-t border-kumo-line">
                        <div className="flex items-center gap-2">
                          <WrenchIcon size={14} className="text-kumo-subtle" />
                          <span className="text-xs text-kumo-subtle">
                            {mcpToolCount} tool
                            {mcpToolCount !== 1 ? "s" : ""} available from MCP
                            servers
                          </span>
                        </div>
                      </div>
                    )}
                  </Surface>
                </div>
              )}
            </div>
            <Button
              variant="secondary"
              icon={<TrashIcon size={16} />}
              onClick={clearHistory}
            >
              Clear
            </Button>
          </div>
        </div>
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-5 py-6 space-y-5">
          {messages.length === 0 && (
            <Empty
              icon={<CloudSunIcon size={32} />}
              title="Start a conversation"
              description='Try "Recommend restaurants in Boston" or "When is my next flight?"'
            />
          )}

          {messages.map((message, index) => {
            const isUser = message.role === "user";
            const isLastAssistant =
              message.role === "assistant" && index === messages.length - 1;

            if (message.role === "system") {
              return <SystemMessage key={message.id} message={message} />;
            }

            if (isUser) {
              return (
                <div key={message.id} className="flex justify-end">
                  <div className="max-w-[85%] px-4 py-2.5 rounded-2xl rounded-br-md bg-kumo-contrast text-kumo-inverse leading-relaxed">
                    {getMessageText(message)}
                  </div>
                </div>
              );
            }

            // Assistant: render parts in order
            return (
              <div key={message.id} className="space-y-2">
                {message.parts.map((part, partIndex) => {
                  // Text
                  if (part.type === "text") {
                    if (!part.text) return null;
                    const isLastTextPart = message.parts
                      .slice(partIndex + 1)
                      .every((p) => p.type !== "text");
                    return (
                      <div key={partIndex} className="flex justify-start">
                        <div className="max-w-[85%] px-4 py-2.5 rounded-2xl rounded-bl-md bg-kumo-base text-kumo-default leading-relaxed">
                          <div className="whitespace-pre-wrap">
                            {part.text}
                            {isLastAssistant &&
                              isLastTextPart &&
                              isStreaming && (
                                <span className="inline-block w-0.5 h-[1em] bg-kumo-brand ml-0.5 align-text-bottom animate-blink-cursor" />
                              )}
                          </div>
                        </div>
                      </div>
                    );
                  }

                  // Reasoning
                  if (part.type === "reasoning") {
                    if (!part.text) return null;
                    return (
                      <div key={partIndex} className="flex justify-start">
                        <Surface className="max-w-[85%] px-4 py-2.5 rounded-xl ring ring-kumo-line opacity-70">
                          <div className="flex items-center gap-2 mb-1">
                            <GearIcon
                              size={14}
                              className="text-kumo-inactive"
                            />
                            <Text size="xs" variant="secondary" bold>
                              Thinking
                            </Text>
                          </div>
                          <div className="whitespace-pre-wrap text-xs text-kumo-subtle italic">
                            {part.text}
                          </div>
                        </Surface>
                      </div>
                    );
                  }

                  // Tool invocations
                  if (!isToolUIPart(part)) return null;
                  const toolName = getToolName(part);
                  const toolInput = part.input as
                    | Record<string, unknown>
                    | undefined;
                  const toolOutput = (part as { output?: unknown }).output;
                  const errorText = (part as { errorText?: string }).errorText;
                  
                  const hasCode =
                    toolInput != null &&
                    typeof toolInput === "object" &&
                    typeof toolInput.code === "string";

                  const isRunning =
                    part.state === "input-available" ||
                    part.state === "input-streaming";
                  const isDone = part.state === "output-available";
                  const isError = part.state === "output-error";
                  const isDenied = part.state === "output-denied";
                  const isApproval =
                    "approval" in part && part.state === "approval-requested";

                  // Tool needs approval
                  if (isApproval) {
                    const approvalId = (part.approval as { id?: string })?.id;
                    return (
                      <div key={part.toolCallId} className="flex justify-start">
                        <Surface className="max-w-[85%] px-4 py-3 rounded-xl ring-2 ring-kumo-warning overflow-hidden">
                          <div className="flex items-center gap-2 mb-2">
                            <GearIcon size={14} className="text-kumo-warning" />
                            <Text size="sm" bold>
                              Approval needed: {toolName}
                            </Text>
                          </div>
                          {toolInput != null && (
                            <pre className="mb-3 p-2 rounded-lg bg-kumo-elevated text-xs font-mono text-kumo-subtle overflow-x-auto max-h-40 overflow-y-auto">
                              {hasCode
                                ? (toolInput.code as string)
                                : JSON.stringify(toolInput, null, 2)}
                            </pre>
                          )}
                          <div className="flex gap-2">
                            <Button
                              variant="primary"
                              size="sm"
                              icon={<CheckCircleIcon size={14} />}
                              onClick={() => {
                                if (approvalId) {
                                  addToolApprovalResponse({
                                    id: approvalId,
                                    approved: true
                                  });
                                }
                              }}
                            >
                              Approve
                            </Button>
                            <Button
                              variant="secondary"
                              size="sm"
                              icon={<XCircleIcon size={14} />}
                              onClick={() => {
                                if (approvalId) {
                                  addToolApprovalResponse({
                                    id: approvalId,
                                    approved: false
                                  });
                                }
                              }}
                            >
                              Reject
                            </Button>
                          </div>
                        </Surface>
                      </div>
                    );
                  }

                  // All other tool states: running, done, error, denied, unknown
                  const statusBadge = isDone ? (
                    <Badge variant="secondary">Done</Badge>
                  ) : isError ? (
                    <Badge variant="destructive">Error</Badge>
                  ) : isDenied ? (
                    <Badge variant="secondary">Denied</Badge>
                  ) : isRunning ? null : (
                    <Badge variant="secondary">{part.state}</Badge>
                  );

                  const statusIcon =
                    isError || isDenied ? (
                      <XCircleIcon size={14} className="text-kumo-inactive" />
                    ) : isRunning ? (
                      <GearIcon
                        size={14}
                        className="text-kumo-inactive animate-spin"
                      />
                    ) : (
                      <GearIcon size={14} className="text-kumo-inactive" />
                    );

                  return (
                    <div key={part.toolCallId} className="flex justify-start">
                      <Surface className="max-w-[85%] px-4 py-2.5 rounded-xl ring ring-kumo-line overflow-hidden">
                        <div className="flex items-center gap-2 mb-1">
                          {statusIcon}
                          <Text size="xs" variant="secondary" bold>
                            {isRunning ? `Running ${toolName}...` : toolName}
                          </Text>
                          {statusBadge}
                        </div>
                        {toolInput != null && (
                          <div className="mt-2">
                            <span className="text-[10px] uppercase tracking-wider text-kumo-inactive font-semibold">
                              Input
                            </span>
                            <pre className="mt-1 p-2 rounded-lg bg-kumo-elevated text-xs font-mono text-kumo-subtle overflow-x-auto max-h-40 overflow-y-auto whitespace-pre-wrap break-all">
                              {hasCode
                                ? (toolInput.code as string)
                                : JSON.stringify(toolInput, null, 2)}
                            </pre>
                          </div>
                        )}
                        {errorText && (
                          <div className="mt-2">
                            <span className="text-[10px] uppercase tracking-wider text-red-400 font-semibold">
                              Error
                            </span>
                            <pre className="mt-1 p-2 rounded-lg bg-red-50 dark:bg-red-950/20 text-xs font-mono text-red-600 dark:text-red-400 overflow-x-auto max-h-40 overflow-y-auto whitespace-pre-wrap break-all">
                              {errorText}
                            </pre>
                          </div>
                        )}
                        {toolOutput != null && (
                          <div className="mt-2">
                            <span className="text-[10px] uppercase tracking-wider text-kumo-inactive font-semibold">
                              Output
                            </span>
                            
                            <pre className="mt-1 p-2 rounded-lg bg-kumo-elevated text-xs font-mono text-kumo-subtle overflow-x-auto max-h-60 overflow-y-auto whitespace-pre-wrap break-all">
                              {formatToolOutput(toolOutput)}
                            </pre>
                          </div>
                        )}
                      </Surface>
                    </div>
                  );
                })}
              </div>
            );
          })}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className="border-t border-kumo-line bg-kumo-base">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            send();
          }}
          className="max-w-3xl mx-auto px-5 py-4"
        >
          <div className="flex items-end gap-3 rounded-xl border border-kumo-line bg-kumo-base p-3 shadow-sm focus-within:ring-2 focus-within:ring-kumo-ring focus-within:border-transparent transition-shadow">
            <InputArea
              value={input}
              onValueChange={setInput}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send();
                }
              }}
              placeholder="Try: When is my next flight? Or: Recommend me some restaurants in New York"
              disabled={!isConnected || isStreaming}
              rows={2}
              className="flex-1 !ring-0 focus:!ring-0 !shadow-none !bg-transparent !outline-none"
            />
            {isStreaming ? (
              <Button
                type="button"
                variant="secondary"
                shape="square"
                aria-label="Stop streaming"
                onClick={stop}
                icon={<StopIcon size={18} weight="fill" />}
                className="mb-0.5"
              />
            ) : (
              <Button
                type="submit"
                variant="primary"
                shape="square"
                aria-label="Send message"
                disabled={!input.trim() || !isConnected}
                icon={<PaperPlaneRightIcon size={18} />}
                className="mb-0.5"
              />
            )}
          </div>
        </form>
        <ProgressPanel progress={progress} tool={progressToolCall} />
        <div className="flex justify-center pb-3">
          <PoweredByCloudflare href="https://developers.cloudflare.com/agents/" />
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <Suspense
      fallback={
        <div className="flex items-center justify-center h-screen text-kumo-inactive">
          Loading...
        </div>
      }
    >
      <Chat />
    </Suspense>
  );
}
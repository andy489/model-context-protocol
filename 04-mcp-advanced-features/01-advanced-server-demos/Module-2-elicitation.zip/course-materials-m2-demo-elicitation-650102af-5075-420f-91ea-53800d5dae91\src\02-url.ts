import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import {
  ElicitRequestParams,
  UrlElicitationRequiredError,
} from "@modelcontextprotocol/sdk/types.js";
import { getAgentByName  } from "agents"; 
import { McpAgent } from "agents/mcp";

type State = {
  acceptedEULA: boolean;
};

export class MyMCP extends McpAgent<Env, State> {
  server = new McpServer({
    name: "Hello MCP Server",
    version: "1.0.0",
  });

  initialState = {
    acceptedEULA: false,
  };

  async init() {
    this.server.server.oninitialized = this.onInitialized.bind(this);

    this.server.registerTool(
      "protected-tool",
      {
        description: "Only runs if the user accepts the EULA",
      },
      async (extras) => {
        if (!this.state.acceptedEULA) {
          throw new UrlElicitationRequiredError(
            [
              this.createEulaElicitation(extras.sessionId!),
            ],
            "You must accept the EULA to use this server.",
          );
        }

        return {
          content: [
            {
              text: `Thanks for accepting the EULA. You are good to go!`,
              type: "text",
            },
          ],
        };
      },
    );
  }

  async onInitialized() {
    const sessionId = this.getSessionId();
    const clientCapabilities = this.server.server.getClientCapabilities();

    if (clientCapabilities?.elicitation?.url && sessionId) {
      console.info(
        "Sending EULA elicitation on initialization.",
      );

      // Send EULA on initialization if the client supports URL elicitation. 
      // This way, the user can accept the EULA before even trying to use the protected tool.
      // This happens "out-of-band" (i.e. not part of a tool call flow)
      await this.server.server.elicitInput(
        this.createEulaElicitation(sessionId));
    } else {
      console.warn(
        "Client does not support URL elicitation. The protected tool will not work properly.",
        clientCapabilities,
      );
    }
  }

  createEulaElicitation(sessionId: string) {
    return {
      mode: "url",
      elicitationId: "accept-eula",
      url: "http://127.0.1:8787/eula?sessionId=" + sessionId,
      message: "Please accept the EULA to continue",
    } satisfies ElicitRequestParams;
  }

  /**
   * This method is called by the /eula endpoint via Worker-to-Agent RPC DO bindings when the user accepts the EULA. 
   * It updates the state and notifies the client that the elicitation is complete.
   */
  async acceptEula() {
    this.setState({ acceptedEULA: true });

    await this.server.server.notification({
      method: "notifications/elicitation/complete",
      params: {
        elicitationId: "accept-eula",
      }
    });
  }
}

export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext<Record<string, unknown>>) {
    const url = new URL(request.url);

    if (url.pathname.endsWith("/eula")) {
      return eulaHandler.fetch(request, env, ctx);
    } else if (url.pathname.endsWith("/mcp")) {
      return mcpHandler.fetch(request, env, ctx);
    }

    return new Response("Not found", { status: 404 });
  },
};

const mcpHandler = MyMCP.serve("/mcp");

const eulaHandler = {
  async fetch(request: Request, env: Env, ctx: ExecutionContext<Record<string, unknown>>) {
    const url = new URL(request.url);
    const sessionId = url.searchParams.get("sessionId");
    if (!sessionId) {
      return new Response("Missing sessionId", { status: 400 });
    }

    // This retrieves the MCP Durable Object instance for the current session
    // which is keyed by streamable-http:${sessionId} as per the `createStreamingHttpHandler` implementation.
    const mcpNs = env.MCP_OBJECT as unknown as DurableObjectNamespace<MyMCP>;
    const mcpAgent = await getAgentByName(mcpNs, `streamable-http:${sessionId}`, { 
      props: ctx.props 
    });

    if (!mcpAgent) {
      return new Response("MCP Agent not found", { status: 404 });
    }

    await mcpAgent.acceptEula();

    return new Response(
      "EULA accepted. You can now use the protected tool.",
      { status: 200 },
    );
  },

};

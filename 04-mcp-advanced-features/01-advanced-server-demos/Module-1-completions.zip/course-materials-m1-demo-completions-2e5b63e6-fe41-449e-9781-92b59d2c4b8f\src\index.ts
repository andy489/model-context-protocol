import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { completable } from "@modelcontextprotocol/sdk/server/completable.js";
import { z } from "zod";
import Color from "colorjs.io";
import colors from "colorjs.io/src/keywords.js";

const server = new McpServer({
  name: "Completions Demo",
  version: "1.0.0",
});

server.registerPrompt(
  "color_haiku",
  {
    description: "Write a haiku about a color, with the option to specify a color and a mood",
    argsSchema: {
      color: completable(
        z
          .string()
          .describe(
            "Well-known CSS color name, hex, or color format to write a haiku about, e.g. red or #ff0000 or rgb(255, 0, 0)",
          ),
        (value) => {
          // Provide list of well-known color names as completions
          const wellKnownColors = Object.keys(colors);

          if (!value) {
            return wellKnownColors;
          }

          return wellKnownColors.filter((color) => color.toLowerCase().startsWith(value.toLowerCase()));
        },
      ),
      mood: z.string().optional().describe("Mood of the haiku, e.g. happy, sad, peaceful"),
    },
  },
  ({ color, mood }) => {
    const c = new Color(color);

    return {
      messages: [
        {
          role: "user",
          content: {
            type: "text",
            text: `Write a haiku about the color '${c.toString()}'${mood ? ` with a ${mood} mood` : ""}:`,
          },
        },
      ],
    };
  },
);

console.error(`MCP Server started...`);

const transport = new StdioServerTransport();
await server.connect(transport);

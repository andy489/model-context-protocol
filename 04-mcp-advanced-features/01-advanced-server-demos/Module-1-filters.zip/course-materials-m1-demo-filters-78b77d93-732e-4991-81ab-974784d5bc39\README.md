## Filters Demo

This demo shows two approaches to applying cross-cutting behaviour to MCP tool handlers: function composition (Demo 1) and a reusable middleware pipeline (Demo 2). Demo 2 extends the middleware approach to restrict which tools are visible based on the `NODE_ENV` environment variable.

## Features / Skills Covered

- **Function composition**: Wrapping individual tool handlers with a `withLogging` higher-order function
- **Middleware pipeline**: Building a composable `withMiddleware` builder that chains logging, caching, and environment-gating behaviours
- **Environment-based tool filtering**: Using an `allowedEnvs` middleware to hide or expose tools based on `NODE_ENV`

## Demos

| Script | File | Concept |
|--------|------|---------|
| `npm run demo1` | `src/01-composition.js` | Function composition — per-tool `withLogging` wrapper |
| `npm run demo2` | `src/02-middleware.ts` | Middleware pipeline — `withMiddleware` builder with env-based tool filtering |

## Prerequisites

- [Node.js LTS](https://nodejs.org) (v22 or later recommended)

## Run Locally

Install dependencies:

```sh
npm install
```

Run Demo 1 (function composition):

```sh
npm run demo1
```

Run Demo 2 (middleware pipeline):

```sh
# Default environment (development)
npm run demo2

# Explicitly set the environment
NODE_ENV=production npm run demo2
```

Launch the MCP Inspector for either demo:

```sh
# Inspect Demo 1
npm run inspect1

# Inspect Demo 2 (development tools visible)
NODE_ENV=development npm run inspect2

# Inspect Demo 2 (production tools visible)
NODE_ENV=production npm run inspect2
```

## VS Code MCP Server

The `.vscode/mcp.json` file registers the following servers for use in Copilot:

- **pluralsight-demo-mcp-filters-composition**: Runs Demo 1 (function composition approach)
- **pluralsight-demo-mcp-filters-middleware**: Runs Demo 2 in production mode (middleware pipeline with env filtering)
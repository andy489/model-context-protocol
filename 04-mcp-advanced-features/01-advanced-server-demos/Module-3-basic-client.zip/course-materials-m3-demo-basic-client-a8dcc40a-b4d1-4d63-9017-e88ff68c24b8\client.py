import asyncio
import json

from fastmcp import Client
from mcp.types import TextResourceContents, TextContent


# ---------------------------------------------------------------------------
# Step 2 — Tools
# ---------------------------------------------------------------------------

async def demo_tools(client: Client) -> None:
    print("\n========== TOOLS ==========")

    # Discover what tools the server exposes
    tools = await client.list_tools()
    print(f"\nAvailable tools ({len(tools)}):")
    for tool in tools:
        print(f"  • {tool.name}: {tool.description}")

    # Submit a new proposal
    print("\n--- Calling: submit_proposal ---")
    result = await client.call_tool(
        "submit_proposal",
        {
            "title": "Observability-Driven Development",
            "speaker": "Dana Kim",
            "topic": "Developer Experience",
            "abstract": (
                "What if observability wasn't an afterthought? This talk makes the "
                "case for designing systems with telemetry as a first-class concern "
                "from day one, covering structured logging, distributed tracing, and "
                "metrics-driven iteration loops."
            ),
        },
    )
    proposal = result.data
    print(f"Submitted proposal: {proposal}")

    # Retrieve the proposal we just submitted by its ID
    print("\n--- Calling: get_proposal ---")
    result = await client.call_tool("get_proposal", {"proposal_id": proposal.id})
    fetched = result.data
    print(f"Fetched proposal: {fetched}")

    # Update its status
    print("\n--- Calling: update_proposal_status ---")
    result = await client.call_tool(
        "update_proposal_status",
        {"proposal_id": proposal.id, "status": "accepted"},
    )

    updated = result.data
    print(f"Updated proposal: {updated}")


# ---------------------------------------------------------------------------
# Step 3 — Resources
# ---------------------------------------------------------------------------

async def demo_resources(client: Client) -> None:
    print("\n========== RESOURCES ==========")

    # Discover what resources the server exposes
    resources = await client.list_resources()
    print(f"\nAvailable resources ({len(resources)}):")
    for resource in resources:
        print(f"  • {resource.uri}: {resource.description}")

    # Read all proposals
    print("\n--- Reading: cfp://proposals ---")
    content = await client.read_resource("cfp://proposals")
    assert isinstance(content[0], TextResourceContents), "Expected text resource"
    proposals = json.loads(content[0].text)
    print(f"Total proposals: {len(proposals)}")
    for p in proposals:
        print(f"  [{p['status'].upper():8}] {p['id']} — {p['title']} ({p['speaker']})")

    # Read accepted topic categories
    print("\n--- Reading: cfp://topics ---")
    content = await client.read_resource("cfp://topics")
    assert isinstance(content[0], TextResourceContents), "Expected text resource"
    topics = json.loads(content[0].text)
    print("Accepted topic categories:")
    for topic in topics:
        print(f"  • {topic}")


# ---------------------------------------------------------------------------
# Step 4 — Prompts
# ---------------------------------------------------------------------------

async def demo_prompts(client: Client) -> None:
    print("\n========== PROMPTS ==========")

    # Discover what prompts the server exposes
    prompts = await client.list_prompts()
    print(f"\nAvailable prompts ({len(prompts)}):")
    for prompt in prompts:
        print(f"  • {prompt.name}: {prompt.description}")

    # Render the review_proposal prompt for an existing proposal
    print("\n--- Getting prompt: review_proposal ---")
    result = await client.get_prompt(
        "review_proposal",
        {
            "title": "Designing for Failure: Resilience Patterns in Distributed Systems",
            "abstract": (
                "This talk explores practical resilience patterns—circuit breakers, "
                "bulkheads, and chaos engineering—through real-world case studies. "
                "Attendees will leave with actionable techniques for building systems "
                "that degrade gracefully under failure."
            ),
        },
    )
    print("Rendered prompt messages:")
    for message in result.messages:
        assert isinstance(message.content, TextContent), "Expected text content"
        print(f"\n[{message.role}]\n{message.content.text}")


# ---------------------------------------------------------------------------
# Step 1 — Connection + entry point
# ---------------------------------------------------------------------------

async def main() -> None:
    print("Connecting to CFP MCP server...")
    
    client = Client("server.py")
    
    async with client:
        await client.ping()
        print("Connected.")

        await demo_tools(client)
        await demo_resources(client)
        await demo_prompts(client)

    print("\nDone.")


if __name__ == "__main__":
    asyncio.run(main())

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { McpAgent } from "agents/mcp";
import { z } from "zod";

export class MyMCP extends McpAgent {
  server = new McpServer({
    name: "Hello MCP Server",
    version: "1.0.0",
  });

  async init() {
    this.server.registerTool(
      "hello",
      {
        description: "Returns a greeting message",
      },
      async () => {

        // Wraps this.server.server.elicitInput with a nicer API
        const nicknameRequest = await this.elicitInput({
          message: "What is your nickname?",
          requestedSchema: z.object({
            nickname: z.string().meta({ 
              title: "Nickname",
              description: "Your nickname"
            }),
          }).toJSONSchema(),
        });

        if (nicknameRequest.action === "accept") {
          return {
            content: [
              {
                text: `Hello, ${nicknameRequest.content?.nickname ?? "World"}!`,
                type: "text",
              },
            ],
          };
        }

        return {
          content: [
            {
              text: `Hello, World!`,
              type: "text",
            },
          ],
        };
      },
    );
  }
}

export default MyMCP.serve("/mcp");

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { McpAgent } from "agents/mcp";
import { z } from "zod";

// The server's "owned" data -- this might be proprietary info, or
// just data that's easier to maintain on the server side.
// The key is that the LLM doesn't have direct access to this data,
// and must rely on the server's tool function to use it.
const DESTINATION_DATA: Record<string, string[]> = {
	tokyo: [
		"Tsukiji Outer Market for breakfast sushi",
		"teamLab Borderless digital art museum",
		"Golden Gai alley bars in Shinjuku",
		"Yanaka neighborhood for old Tokyo atmosphere",
	],
	lisbon: [
		"LX Factory Sunday market",
		"Time Out Market for local food scene",
		"Sintra day trip for Pena Palace",
		"Pastéis de Belém for the original custard tart",
	],
};

export class MyMCP extends McpAgent {
	server = new McpServer({
		name: "Trip Planner MCP Server",
		version: "1.0.0",
	});

	async init() {
		this.server.registerTool(
			"plan_trip",
			{
				description: "Plans a trip itinerary using curated local recommendations",
				inputSchema: z.object({
					destination: z.string().describe("City to visit (e.g. tokyo, lisbon)"),
					days: z.number().describe("Number of days"),
				}),
			},
			async ({ destination, days }) => {
				const spots = DESTINATION_DATA[destination.toLowerCase()];

				if (!spots) {
					return {
						content: [
							{ type: "text", text: `No recommendations found for ${destination}.` },
						],
					};
				}

				// Here's the Sampling call -- server asking the client's LLM to do the synthesis
				const result = await this.server.server.createMessage({
					maxTokens: 512,
					messages: [
						{
							role: "user",
							content: {
								type: "text",
								text: `Create a ${days}-day itinerary for ${destination} using ONLY these curated spots:
${spots.map((s, i) => `${i + 1}. ${s}`).join("\n")}

Spread them across the ${days} days naturally. Be concise.`,
							},
						},
					],
				});

				const itinerary =
					result.content.type === "text"
						? result.content.text
						: "Could not generate itinerary.";

				return {
					content: [{ type: "text", text: itinerary }],
				};
			},
		);
	}
}

export default MyMCP.serve("/mcp");

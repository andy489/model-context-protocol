## Sampling Demo

This demo shows MCP sampling — the ability for a server to request LLM inference from the connected client rather than processing it locally. Demo 1 performs a basic sampling call; Demo 2 extends this by passing tool definitions to the LLM so it can call tools during the sampling response.

## Features / Skills Covered

- **`createMessage`**: Calling `server.server.createMessage()` from inside a tool handler to delegate LLM inference to the client
- **Sampling without tools**: A minimal sampling call that asks the client's LLM to synthesise a trip itinerary from curated data
- **Sampling with tools**: Passing `tools` in the `createMessage` request and handling multi-turn tool use within the sampling response

## Demos

| Script | File | Concept |
|--------|------|---------|
| `npm run demo1` | `src/01-without-tools.ts` | Basic sampling — server delegates LLM synthesis to the client |
| `npm run demo2` | `src/02-with-tools.ts` | Sampling with tools — client LLM can invoke tools during inference |

## Prerequisites

- [Node.js LTS](https://nodejs.org) (v22 or later recommended)
- [Cloudflare account](https://dash.cloudflare.com/sign-up) — required for Wrangler
- [Wrangler CLI](https://developers.cloudflare.com/workers/wrangler/install-and-update/) — authenticate once with `npx wrangler login`

## Run Locally

Install dependencies:

```sh
npm install
```

Start a demo (runs on `http://127.0.0.1:8787/mcp`):

```sh
npm run demo1
# or
npm run demo2
```

In a separate terminal, launch the MCP Inspector:

```sh
npm run inspect
```

## Deploy to Cloudflare

```sh
npm run deploy
```

## VS Code MCP Server

The `.vscode/mcp.json` file registers the following server for use in Copilot:

- **pluralsight-demo-sampling**: Connects to the locally running server at `http://127.0.0.1:8787/mcp`

> Connect after running `npm run demo1` or `npm run demo2`.

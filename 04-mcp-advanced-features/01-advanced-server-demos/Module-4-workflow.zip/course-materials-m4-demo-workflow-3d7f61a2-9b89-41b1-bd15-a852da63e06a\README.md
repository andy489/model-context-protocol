## Agentic Workflow Demo

This demo consists of two servers that work together:

- `mcp-trip-advisor` — A Cloudflare Worker MCP server exposing trip-planning tools
- `agent-planner` — A Cloudflare Worker that hosts the AI chat agent and serves the React frontend

## Features / Skills Covered

- **`McpAgent` with Durable Objects**: Hosting a long-lived AI agent (`TripPlannerAgent`) with persistent state per session
- **Cloudflare Workflows**: Orchestrating a multi-step `FlightSearchWorkflow` with automatic retries and state persistence
- **Workers AI binding**: Delegating LLM inference to Cloudflare's remote AI infrastructure via the `AI` binding
- **MCP client inside an agent**: The `agent-planner` connects to `mcp-trip-advisor` at runtime to call trip-planning tools via the MCP protocol
- **React frontend**: A Vite + React chat UI served from the same Worker via the `assets` binding

## Prerequisites

- [Node.js LTS](https://nodejs.org) (v22 or later recommended)
- [Cloudflare account](https://dash.cloudflare.com/sign-up) — required for Wrangler and Workers AI
- [Wrangler CLI](https://developers.cloudflare.com/workers/wrangler/install-and-update/) — authenticate once with `npx wrangler login`

> **Workers AI usage charges**: The `agent-planner` server uses the Workers AI binding (`AI`) with `"remote": true`, which routes inference requests to Cloudflare's AI infrastructure. This **will incur usage charges** on your Cloudflare account. Check the [Workers AI pricing page](https://developers.cloudflare.com/workers-ai/platform/pricing/) before running the demo.

## Run Locally

Install dependencies for both servers:

```sh
cd mcp-trip-advisor
npm install

cd ../agent-planner
npm install
```

Authenticate Wrangler if you haven't already:

```sh
npx wrangler login
```

Both servers must be running at the same time. Open two terminal windows.

### Terminal 1 — MCP Trip Advisor (port 8787)

```sh
cd mcp-trip-advisor
npm start
```

This starts the MCP server locally via `wrangler dev`. It exposes trip-planning tools on `http://localhost:8787`.

### Terminal 2 — Agent Planner (frontend + agent)

```sh
cd agent-planner
npm start
```

This starts the Vite dev server with the Cloudflare plugin. Open the URL printed in the terminal (typically `http://localhost:5173`) to interact with the agent in your browser.

## How It Works

1. The **agent-planner** hosts a `TripPlannerAgent` (Durable Object) and a `FlightSearchWorkflow` (Cloudflare Workflow).
2. The agent connects to the **mcp-trip-advisor** server to call trip-planning tools via the MCP protocol.
3. Workers AI (via the `AI` binding) drives the LLM responses, using Cloudflare's remote inference infrastructure.


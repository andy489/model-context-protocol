## Sampling Client-Server Demo

This demo pairs a TypeScript MCP server (hosted via Cloudflare Wrangler) with a Python FastMCP client to show the full sampling flow end-to-end. The client calls a `plan_trip` tool on the server, which in turn sends a `createMessage` sampling request back to the client's LLM (Anthropic Claude) to synthesise the trip itinerary.

## Features / Skills Covered

- **Client-driven sampling**: A Python FastMCP client that connects to a remote MCP server over HTTP and handles incoming sampling requests
- **`createMessage` from TypeScript**: The server requests LLM inference from the client using the MCP sampling protocol
- **Anthropic integration**: Using `fastmcp[anthropic]` to provide the LLM backend for sampling responses

## Files

| Directory | Purpose |
|-----------|---------|
| `server/` | TypeScript MCP server (Cloudflare Worker) — exposes the `plan_trip` tool and issues sampling requests |
| `client/` | Python FastMCP client — connects to the server, calls tools, and handles incoming sampling requests |

## Prerequisites

- [Node.js LTS](https://nodejs.org) (v22 or later recommended) — for the server
- [Python 3.10+](https://www.python.org/downloads/) — for the client
- [Cloudflare account](https://dash.cloudflare.com/sign-up) — required for Wrangler
- [Wrangler CLI](https://developers.cloudflare.com/workers/wrangler/install-and-update/) — authenticate once with `npx wrangler login`
- [Anthropic API key](https://console.anthropic.com/) — required to run the `plan` command

## Run Locally

Both the server and client must be running. Open two terminal windows.

### Terminal 1 — MCP Server (port 8787)

```sh
cd server
npm install
npm start
```

### Terminal 2 — Python Client

Create and activate a virtual environment, then install client dependencies.

#### Windows (PowerShell)

```powershell
python -m venv .venv
# If you get an execution-policy error, run this first:
Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned
.venv\Scripts\activate
pip install -r client\requirements.txt
```

#### macOS / Linux

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r client/requirements.txt
```

## Environment Variables

Copy the example env file and add your Anthropic API key:

```sh
cp client/.env.example client/.env
```

`client/.env` format:

```dotenv
ANTHROPIC_API_KEY=<your-anthropic-api-key>
```

## Usage

Run the script without arguments to see help:

```sh
python client/run_sampling_client.py
```

### Probe the running server

Verify the server is reachable and list its exposed tools:

```sh
python client/run_sampling_client.py probe
```

### Plan a trip (uses Anthropic)

```sh
python client/run_sampling_client.py plan --destination lisbon --days 3
```

Optional flags:

- `--server-url` — target a different MCP endpoint
- `--model` — override the default Anthropic model
- `--destination` and `--days` — vary the trip-planning request

## VS Code MCP Server

The `.vscode/mcp.json` file registers the following server for use in Copilot:

- **pluralsight-demo-sampling**: Connects to the locally running server

> Connect after running `npm start` in the `server/` directory.

## Troubleshooting

**Execution policy error on Windows**: Run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned` before activating the virtual environment.

**`ANTHROPIC_API_KEY` not found**: Ensure `client/.env` exists and contains your key. Copy `client/.env.example` to `client/.env` and fill in the value.

import { createMcpHandler } from "agents/mcp";
import { DynamicWorkerExecutor } from "@cloudflare/codemode";
import { openApiMcpServer } from "@cloudflare/codemode/mcp";
import spec from './tripadvisor-v1-spec.json';

export default {
  async fetch(
    request: Request,
    env: Env,
    ctx: ExecutionContext
  ): Promise<Response> {
    const token = env.TRIP_ADVISOR_API_KEY;
    if (!token) {
      return new Response("Missing TRIP_ADVISOR_API_KEY", { status: 500 });
    }
    const executor = new DynamicWorkerExecutor({ loader: env.LOADER });

    const server = openApiMcpServer({
      spec,
      executor,
      name: "tripadvisor",
      description: `This server wraps the TripAdvisor API. Replace path parameters like {location} and {locationId} with real values from a prior search or list call.

// Search for a city or location name (e.g., Tokyo, New York). For the best results, include the city, state, and country (e.g., "Tokyo, Japan" or "Boston, MA"). You can
// also filter by specific location types like restaurants, hotels, or attractions.
async () => {
  return await codemode.request({ method: "GET", path: "/location/search", query: { searchQuery: "Tokyo, Japan", category: "restaurants" // or "hotels", "attractions", etc. } });
}

// Get location details for reviews, address, etc. using a location ID from a search result
// You can send multiple locations in parallel using Promise.all to get details for each.
//
// Example: get a single location details
async () => {
  return await codemode.request({ method: "GET", path: "/location/{locationId}/details", query: { locationId: "12345" } });
}
// Example: get multiple location details in parallel (up to 10)
async () => {
  const locationIds = ["12345", "67890", "11223", ...];
  return await Promise.all(locationIds.map(id => codemode.request({ method: "GET", path: \`/location/\${id}/details\` })));
}
`,
      // This is where you call your API. Runs on the host — auth, base URL,
      // headers are all yours. The sandbox never sees tokens or secrets.
      request: async (opts) => {
        const url = new URL(`https://api.content.tripadvisor.com/api/v1${opts.path}`);
        if (opts.query) {
          for (const [key, value] of Object.entries(opts.query)) {
            if (value !== undefined) url.searchParams.set(key, String(value));
          }
        }
        url.searchParams.set("key", token);

        const headers: Record<string, string> = {
            'accept': 'application/json'
        };
        if (opts.contentType) {
          headers["Content-Type"] = opts.contentType;
        } else if (opts.body) {
          headers["Content-Type"] = "application/json";
        }

        const res = await fetch(url.toString(), {
          method: opts.method,
          headers,
          body: opts.body
            ? opts.rawBody
              ? (opts.body as string)
              : JSON.stringify(opts.body)
            : undefined
        });

        return await res.json();
      }
    });

    return createMcpHandler(server)(request, env, ctx);
  }
};
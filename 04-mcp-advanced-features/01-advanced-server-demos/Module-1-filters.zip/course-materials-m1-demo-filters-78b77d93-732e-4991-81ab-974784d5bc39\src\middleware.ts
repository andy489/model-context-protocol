import type {
  JSONRPCRequest,
  Result,
} from "@modelcontextprotocol/sdk/types.js";
import type { RequestHandlerExtra } from "@modelcontextprotocol/sdk/shared/protocol.js";
import {
  type ServerNotification,
  type ServerRequest,
} from "@modelcontextprotocol/sdk/types.js";
import type {
  McpServer,
  RegisteredTool,
} from "@modelcontextprotocol/sdk/server/mcp.js";

// Middleware system with chaining support
type MiddlewareHandler = (
  request: JSONRPCRequest,
  extra: RequestHandlerExtra<ServerRequest, ServerNotification>,
  next: () => Promise<Result>,
) => Promise<Result>;

export function withMiddleware(server: McpServer) {
  const middlewares: MiddlewareHandler[] = [];
  const originalSetRequestHandler = server.server.setRequestHandler.bind(
    server.server,
  );

  // Override setRequestHandler to inject middleware chain
  server.server.setRequestHandler = (schema, handler) => {
    return originalSetRequestHandler(schema, async (request, extra) => {
      // Build middleware chain from the end
      let index = 0;

      const next = async (): Promise<Result> => {
        if (index < middlewares.length) {
          const middleware = middlewares[index++];
          return middleware(request, extra, next);
        }
        // End of chain - call the actual handler
        return handler(request, extra);
      };

      return next();
    });
  };

  return {
    use(middleware: MiddlewareHandler) {
      middlewares.push(middleware);
      return this; // Allow chaining
    },
  };
}

// Logging middleware
export function logging(): MiddlewareHandler {
  return async (request, extra, next) => {
    const startTime = Date.now();
    console.error(
      `[Middleware:Logging] → ${request.method} (request_id: ${extra.requestId})`,
    );

    const result = await next();

    const duration = Date.now() - startTime;
    console.error(
      `[Middleware:Logging] ← ${request.method} completed in ${duration}ms`,
    );

    return result;
  };
}

// Caching middleware (simulated)
export function caching(): MiddlewareHandler {
  const cache = new Map<string, { value: any; expires: number }>();

  return async (request, extra, next) => {
    // Only cache tool calls (check if it looks like a tool-related request)
    if (request.method === "tools/call") {
      const params = request.params ?? {};
      delete params._meta; // Remove non-essential params from cache key
      const cacheKey = JSON.stringify({ method: request.method, params });
      const cached = cache.get(cacheKey);

      if (cached && Date.now() < cached.expires) {
        console.error(
          `[Middleware:Caching] 🎯 Cache HIT for ${request.method}`,
        );
        return cached.value;
      }

      console.error(`[Middleware:Caching] ❌ Cache MISS for ${request.method}`);
      const result = await next();

      // Cache for 5 seconds
      cache.set(cacheKey, { value: result, expires: Date.now() + 5000 });

      return result;
    }

    return next();
  };
}

export function allowedEnvs(
  environment: string,
  server: McpServer,
): MiddlewareHandler {
  const onInitialized = server.server.oninitialized;
  server.server.oninitialized = () => {
    onInitialized?.();

    // Access private property to get registered tools and their metadata
    const registeredTools: Record<string, RegisteredTool> | undefined =
      server["_registeredTools"];

    if (!registeredTools) {
      throw new Error(
        "Unable to access registered tools for environment filtering",
      );
    }

    // Log the registered tools and their allowed environments for debugging
    Object.entries(registeredTools).forEach(([toolName, tool]) => {
      const allowedEnvs = tool._meta?.allowedEnvs as string[] | undefined;
      if (allowedEnvs && !allowedEnvs.includes(environment)) {
        console.error(
          `[Middleware:AllowedEnvs] Tool "${toolName}" is restricted to environments: ${allowedEnvs.join(", ")}`,
        );

        // Disable the tool if it's not allowed in the current environment
        tool.enabled = false;
      }
    });
  };

  return (request, extra, next) => {
    // You do not need to filter tools/list calls here since we disable the tools at startup based on their metadata.
    // However, if the tool list changes dynamically, you might want
    // to re-check allowed environments by setting a notification handler for notifications/tools/list_changed and updating tool availability accordingly.

    return next();
  };
}

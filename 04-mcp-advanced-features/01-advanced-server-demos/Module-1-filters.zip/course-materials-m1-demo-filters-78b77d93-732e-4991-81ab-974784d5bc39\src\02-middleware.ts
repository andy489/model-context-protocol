import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { allowedEnvs, caching, logging, withMiddleware } from "./middleware.ts";

const environment = process.env.NODE_ENV || "development";

const server = new McpServer({
  name: "Filter Demo",
  version: "1.0.0",
});

// A: Hack around setRequestHandler
// const originalSetRequestHandler = server.server.setRequestHandler.bind(server.server);
// server.server.setRequestHandler = (schema, handler) => {
//   return originalSetRequestHandler(schema, async (request, extra) => {
//     const startTime = Date.now();
//     console.error(
//       `[Middleware:Logging] → ${request.method} (request_id: ${extra.requestId})`,
//     );

//     const result = await handler(request, extra);

//     const duration = Date.now() - startTime;
//     console.error(
//       `[Middleware:Logging] ← ${request.method} completed in ${duration}ms`,
//     );
//     return result;
//   });
// }

// B: Build a middleware pipeline
withMiddleware(server)
  .use(logging())
  .use(caching())
  .use(allowedEnvs(environment, server));

// Tool available in ALL environments
server.registerTool(
  "get_status",
  {
    description: "Get the current system status"
  },
  async () => {
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(
            {
              status: "operational",
              environment: environment,
              timestamp: new Date().toISOString(),
            },
            null,
            2,
          ),
        },
      ],
    };
  },
);

// Tool available ONLY in development
server.registerTool(
  "debug_logs",
  {
    description: "View detailed debug logs (development only)",
    inputSchema: {
      level: z
        .enum(["verbose", "debug", "trace"])
        .optional()
        .describe("Log level to retrieve"),
    },
    _meta: {
      allowedEnvs: ["development"]
    }
  },
  async ({ level }) => {
    const logLevel = level || "debug";
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(
            {
              message: "Debug logs retrieved",
              level: logLevel,
              logs: [
                "Request processing started at 10:23:45",
                "Database query executed in 45ms",
                "Cache hit for key: user_profile_123",
                "Response sent with status 200",
              ],
            },
            null,
            2,
          ),
        },
      ],
    };
  }
);

console.error(`MCP Server starting in ${environment} mode...`);

const transport = new StdioServerTransport();
await server.connect(transport);
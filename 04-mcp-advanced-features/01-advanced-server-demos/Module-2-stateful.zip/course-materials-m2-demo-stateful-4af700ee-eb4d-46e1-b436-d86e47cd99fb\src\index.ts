import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { McpAgent } from "agents/mcp";
import { z } from "zod";

export class MyMCP extends McpAgent {
  server = new McpServer({
    name: "Hello MCP Server",
    version: "1.0.0",
  });

  async init() {
    this.server.registerTool(
      "hello",
      {
        description: "Returns a greeting message",
        inputSchema: { name: z.string().optional() },
      },
      async ({ name }, extra) => {
        return {
          content: [
            {
              text: `Hello, ${name ?? "World"}!`,
              type: "text",
            },
            {
              text: `Session ID: ${extra.sessionId}`,
              type: "text",
            },
          ],
        };
      },
    );
  }
}

export default MyMCP.serve("/mcp");

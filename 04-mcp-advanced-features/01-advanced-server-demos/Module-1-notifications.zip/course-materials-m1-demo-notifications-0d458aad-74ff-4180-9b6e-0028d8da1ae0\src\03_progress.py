"""
Demo 3 — Progress Notifications

Shows how a tool can stream incremental progress updates to the client during a
long-running operation using `ctx.report_progress()`.

The client must send a `progressToken` in its initial request to opt in to
receiving progress updates. MCP Inspector does this automatically.
"""

import asyncio

from fastmcp import FastMCP, Context

mcp = FastMCP(name="Notifications Demo")

_DEPLOYMENT_STEPS = [
    "Validating configuration",
    "Pulling container image",
    "Provisioning infrastructure",
    "Starting containers",
    "Running health checks",
    "Updating DNS records",
    "Notifying monitoring system",
]


@mcp.tool(description="Run a simulated multi-step deployment with progress reporting")
async def run_deployment(environment: str, ctx: Context) -> str:
    """
    Simulates a deployment pipeline and reports progress after each step.

    Each call to `ctx.report_progress()` sends a
    `notifications/progress` notification to the client so it can display
    a live progress indicator.
    """
    total = len(_DEPLOYMENT_STEPS)

    await ctx.info(f"Starting deployment to '{environment}'...")

    for i, step in enumerate(_DEPLOYMENT_STEPS):
        await ctx.report_progress(progress=i, total=total, message=f"Step {i + 1}/{total}: {step}")
        await asyncio.sleep(0.8)  # Simulate work

    await ctx.report_progress(progress=total, total=total)

    return f"Deployment to '{environment}' completed successfully ({total} steps)."


if __name__ == "__main__":
    mcp.run()

## Basic FastMCP Client

A self-contained Python demo showing how to build a FastMCP client that connects to a local MCP server programmatically. The server models a **Call for Papers (CFP) management system** — a realistic domain that maps naturally to MCP's tools, resources, and prompts primitives.

## Features / Skills Covered

- **FastMCP client**: Connecting to a local MCP server over stdio transport using `fastmcp.Client`
- **Tools**: Discovering and calling server tools (`list_tools`, `call_tool`)
- **Resources**: Listing and reading server resources (`list_resources`, `read_resource`)
- **Prompts**: Listing and rendering server prompts (`list_prompts`, `get_prompt`)
- **`fastmcp inspect` / `fastmcp list`**: Using the FastMCP CLI to explore a server without writing client code

## Files

| File | Purpose |
|------|--------|
| `server.py` | FastMCP server — CFP management with tools, resources, and a prompt |
| `client.py` | FastMCP client — exercises every primitive step-by-step |
| `demo.py` | Demo helper functions called by `client.py` to exercise each primitive |

## Prerequisites

- Python 3.10+
- A virtual environment with dependencies installed

```bash
python -m venv .venv

# Windows (if you get an execution policy error, run this first in your terminal)
# Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned
.venv\Scripts\activate

# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
```

## Running the Demo

With the virtual environment active, run the client. It starts the server automatically as a subprocess via stdio transport — no separate terminal needed.

```bash
python client.py
```

Expected output walks through four sections: connection, tools, resources, and prompts.

## Inspecting the Server with the FastMCP CLI

The `fastmcp` CLI lets you explore and exercise the server interactively without writing any client code — useful for development and debugging.

### Summary view

```bash
fastmcp inspect server.py
```

Shows a human-readable summary of all tools, resources, and prompts registered on the server.

### Full JSON output

```bash
# FastMCP-extended format (includes tags, schemas, metadata)
fastmcp inspect server.py --format fastmcp

# MCP protocol format (exactly what a client sees)
fastmcp inspect server.py --format mcp
```

### List tools, resources, and prompts

```bash
# Tools only (default)
fastmcp list server.py

# All primitives
fastmcp list server.py --resources --prompts

# With full input/output schemas
fastmcp list server.py --input-schema --output-schema

# Machine-readable JSON (useful for feeding to an LLM)
fastmcp list server.py --resources --prompts --json
```

### Call tools directly from the CLI

```bash
# Get a pre-seeded proposal
fastmcp call server.py get_proposal proposal_id=prop-001

# Submit a new proposal (complex argument as JSON)
fastmcp call server.py submit_proposal '{"title": "My Talk", "speaker": "Ada Lovelace", "topic": "Programming Languages", "abstract": "A deep dive into the history and future of programming languages."}'

# Update a proposal status
fastmcp call server.py update_proposal_status proposal_id=prop-001 status=accepted
```

## Server Primitives

### Tools

| Tool | Description |
|---|---|
| `submit_proposal` | Submit a new proposal — returns the created `Proposal` with an assigned ID |
| `get_proposal` | Retrieve a single proposal by ID |
| `update_proposal_status` | Set a proposal's status to `pending`, `accepted`, or `rejected` |

### Resources

| URI | Description |
|---|---|
| `cfp://proposals` | JSON list of all proposals (pre-seeded + submitted) |
| `cfp://topics` | JSON list of accepted topic categories |

### Prompts

| Prompt | Description |
|---|---|
| `review_proposal` | Renders a structured LLM review prompt for a given title and abstract |

## Domain Model

```python
class ProposalStatus(str, Enum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    REJECTED = "rejected"

class Proposal(BaseModel):
    id: str
    title: str
    speaker: str
    topic: str
    abstract: str
    status: ProposalStatus
```

## Next Steps

The CFP domain is designed to extend into an agentic workflow. A natural next step is an agent that:

1. Reads `cfp://proposals` to get all pending submissions
2. Calls `get_prompt("review_proposal", ...)` for each one
3. Sends the rendered prompt to an LLM and parses the score
4. Calls `update_proposal_status` to accept or reject based on the result

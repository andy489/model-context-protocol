// This is a Cloudflare Worker that implements an AI travel agent using @cloudflare/ai-chat.
// The agent can use tools from connected MCP servers,
// and perform server-side functions. It also demonstrates proactive messaging by sending
// a system message whenever a workflow completes to notify the user.
// This is based on the sample: https://github.com/cloudflare/agents/tree/main/examples/ai-chat

import { createWorkersAI } from "workers-ai-provider";
import {
  routeAgentRequest,
  callable,
  getAgentByName,
} from "agents";
import {
  AIChatAgent,
  type OnChatMessageOptions,
  type ChatResponseResult,
} from "@cloudflare/ai-chat";
import {
  streamText,
  convertToModelMessages,
  pruneMessages,
  tool,
  stepCountIs,
} from "ai";
import { z } from "zod";
import { nanoid } from "nanoid";
export { FlightSearchWorkflow } from "./workflow";

type AgentState = {
  currentWorkflow?: string;
  status?: string;
};

export class TripPlannerAgent extends AIChatAgent<Env, AgentState> {

  initialState: AgentState = {};

  // Keep the last 200 messages in SQLite storage
  maxPersistedMessages = 200;

  // Wait for MCP connections to restore after hibernation before processing messages
  waitForMcpConnections = true;

  onStart() {
    // Add Trip Advisor MCP server on startup
    // If this was a real MCP server Worker that we controlled, you could add it using bindings for Agent-to-Agent communication.
    // This is an example where we are treating the MCP server as a third-party service, so we add it via the URL.
    // The server could be running anywhere - locally, on another cloud provider, or even on Cloudflare Workers in a different account.
    this.addMcpServer("TripAdvisor", "http://127.0.0.1:8787/mcp");
  }

  // Start a flight search task - called via HTTP or WebSocket
  async startFlightSearch(task: string) {
    const instanceId = await this.runWorkflow("FLIGHT_SEARCH_WORKFLOW", { task });

    console.log("[agent] Started flight search workflow with instanceId:", instanceId);

    this.setState({
      ...this.state,
      currentWorkflow: instanceId,
      status: "running",
    });

    return { instanceId };
  }

  // Get status of a workflow
  async getFlightSearchStatus(instanceId: string) {
    return this.getWorkflow(instanceId);
  }

  async onChatMessage(_onFinish: unknown, options?: OnChatMessageOptions) {
    const workersai = createWorkersAI({ binding: this.env.AI });

    const result = streamText({
      abortSignal: options?.abortSignal,

      // Use WorkersAI as the model provider
      model: workersai("@cf/qwen/qwen3-30b-a3b-fp8", {
        sessionAffinity: this.sessionAffinity,
      }),

      // Define system instructions and tool availability for the agent's context
      system:
        "You are a helpful travel assistant. You can plan itineraries based on a location, get the user's next flight, " +
        "and use Trip Advisor to search for locations and get recommendations, reviews, and ratings. " +
        "For making a booking call to a location, you need user approval first.",

      // Prune old tool calls and reasoning to save tokens on long conversations
      messages: pruneMessages({
        messages: await convertToModelMessages(this.messages),
        toolCalls: "before-last-2-messages",
        reasoning: "before-last-message",
      }),
      tools: {
        // MCP tools from connected servers
        ...this.mcp.getAITools(),

        // Kicks off the flight search workflow
        getUserNextFlight: tool({
          description:
            "Get the user's next flight. Use this when you need to know the user's upcoming travel plans.",
          inputSchema: z.object({}),
          execute: async () => {
            // The workflow simulates checking the user's calendar,
            // finding flight events, extracting details, and searching for the flight status,
            // with progress updates along the way. 
            // The client can call getFlightSearchStatus to get real-time updates on the workflow's progress.
            const workflow = await this.startFlightSearch(
              "Get next flight for user",
            );

            return {
              instanceId: workflow.instanceId,
              message:
                "Started looking for your next flight. I'll send progress updates as they happen, you don't need to wait for me.",
            };
          },
        }),

        getUserFlightSearchStatus: tool({
          description: "Get the status of the user's next flight search. Use this to get real-time updates on the progress of the flight search. Always execute this even if the user previously called it in the conversation because the status may have changed.",
          inputSchema: z.object({
            instanceId: z.string().describe("The ID of the flight search workflow instance. If user does not provide instance ID, you don't need to pass one and it will get the current running instance.").optional(),
          }),
          execute: async (params) => {
            const instanceId = params.instanceId ?? this.state.currentWorkflow;

            if (!instanceId) {
              throw new Error("Instance ID was not provided and no current flight search is available. Was there a next flight search kicked off?");
            }

            const status = await this.getFlightSearchStatus(instanceId);
            return status;
          }
        }),
      },

      // Stop the response if the workflow has executed too many steps to prevent runaways
      stopWhen: stepCountIs(30),
    });

    return result.toUIMessageStreamResponse();
  }

  protected async onChatResponse(result: ChatResponseResult) {
    if (result.status === "completed") {
      this.broadcast(JSON.stringify({ type: "streaming_done" }));
    }
  }

  // Called when workflow reports progress
  async onWorkflowProgress(
    workflowName: string,
    instanceId: string,
    progress: unknown,
  ) {
    // Broadcast to all connected WebSocket clients
    this.broadcast(JSON.stringify({ type: "progress", instanceId, progress }));
  }

  // Called when workflow completes
  async onWorkflowComplete(
    workflowName: string,
    instanceId: string,
    result?: unknown,
  ) {
    this.setState({ ...this.state, status: "complete" });
    this.broadcast(JSON.stringify({ type: "complete", instanceId, result }));

    await this.saveMessages(messages => [
      ...messages,
      {
        id: nanoid(),
        role: "system" as const,
        parts: [
          {
            type: "text" as const,
            text: `Finished workflow ${workflowName} with result: ${JSON.stringify(result)}. Summarize the result for the user and offer to follow-up with additional actions.`
          },
        ],
      }
    ])
  }

  // Called when workflow errors
  async onWorkflowError(
    workflowName: string,
    instanceId: string,
    error: string,
  ) {
    this.setState({ ...this.state, status: "error" });
    this.broadcast(JSON.stringify({ type: "error", instanceId, error }));
  }

}

export default {
  async fetch(request: Request, env: Env) {
    const url = new URL(request.url);

    // HTTP API for starting flight search tasks
    if (request.method === "POST" && url.pathname === "/agents/flight-search") {
      const { task, agentId } = await request.json<{
        task: string;
        agentId?: string;
      }>();

      // Get agent instance by name (creates if doesn't exist)
      const agent = await getAgentByName(
        env.TripPlannerAgent,
        agentId ?? "default",
      );

      // Start the flight search workflow via RPC
      const result = await agent.startFlightSearch(task);
      return Response.json(result);
    }

    // Check flight search workflow status
    if (url.pathname === "/agents/flight-search/status") {
      const instanceId = url.searchParams.get("instanceId");
      const agentId = url.searchParams.get("agentId") ?? "default";

      if (!instanceId) {
        return Response.json({ error: "instanceId required" }, { status: 400 });
      }

      const agent = await getAgentByName(env.TripPlannerAgent, agentId);
      const status = await agent.getFlightSearchStatus(instanceId);

      return Response.json(status);
    }

    // Route agent requests (tool calls, workflow updates, etc.) to the agent handler
    const response = await routeAgentRequest(request, env);
    if (response) return response;

    return new Response("Not found", { status: 404 });
  },
} satisfies ExportedHandler<Env>;

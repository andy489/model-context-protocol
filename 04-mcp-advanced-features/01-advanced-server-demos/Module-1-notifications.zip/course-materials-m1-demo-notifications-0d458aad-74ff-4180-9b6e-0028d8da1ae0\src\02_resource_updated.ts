// Demo 2 - Resource Updated Notifications
// This demo shows how to use the MCP SDK to create a server that allows clients to subscribe to a resource and receive notifications when that resource is
// updated. In this example, we have a simple system status resource that clients can subscribe to. When the status is updated via a tool,
// all subscribed clients will receive a notification about the update.
//
// To test with the MCP inspector, the following patch is required:
// https://github.com/modelcontextprotocol/inspector/pull/1148

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
	SubscribeRequestSchema,
	UnsubscribeRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import { z } from "zod";

const server = new McpServer(
	{
		name: "Resource Subscriptions Demo",
		version: "1.0.0",
	},
	{
		capabilities: {
			resources: { subscribe: true },
		},
	},
);

// Store client susbscriptions in memory (for demo purposes - in production, consider a more robust storage solution)
const subscriptions = new Set<string>();
const systemState = {
	status: "operational",
};

server.server.setRequestHandler(SubscribeRequestSchema, async (request) => {
	subscriptions.add(request.params.uri);
	return {};
});

server.server.setRequestHandler(UnsubscribeRequestSchema, async (request) => {
	subscriptions.delete(request.params.uri);
	return {};
});

server.registerResource(
	"system_status",
	"system://status",
	{
		description: "Current status of the system",
	},
	async (uri) => ({
		contents: [{ uri: uri.href, text: systemState.status }],
	}),
);

server.registerTool(
	"update_system_status",
	{
		description: "Update the system status and notify subscribed clients",
		inputSchema: {
			status: z
				.string()
				.describe("New status of the system, e.g. operational, degraded, maintenance"),
		},
	},
	async ({ status }) => {
		// Update system state
		systemState.status = status;

		const resourceUri = "system://status";

		// Notify subscribed clients about the state change
		if (subscriptions.has(resourceUri)) {
			await server.server.sendResourceUpdated({ uri: resourceUri });
			server.sendResourceListChanged();
		}

		return {
			content: [
				{
					type: "text",
					text: `System status updated to '${status}' and notifications sent to subscribed clients.`,
				},
			],
		};
	},
);

console.error(`MCP Server started...`);

const transport = new StdioServerTransport();
await server.connect(transport);

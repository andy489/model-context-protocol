## Roots Demo

This demo shows how MCP clients declare filesystem roots — path prefixes that the server is permitted to access — and how a server reads and reacts to those declarations. Demo 1 scans all declared roots when the client connects; Demo 2 also subscribes to `roots/list_changed` notifications and updates its state when the client adds or removes roots at runtime.

## Features / Skills Covered

- **`roots` capability**: Reading client-declared filesystem roots via `server.server.listRoots()`
- **`oninitialized` hook**: Fetching roots after the MCP protocol handshake completes
- **`roots/list_changed` notification**: Subscribing to runtime updates when the client's root set changes
- **Capability negotiation**: Checking `getClientCapabilities()` before using optional client features

## Demos

| Script | File | Concept |
|--------|------|---------|
| `npm run demo1` | `src/01-directories.ts` | Read declared roots on connect and return a filesystem summary |
| `npm run demo2` | `src/02-changes.ts` | Subscribe to root changes and update server state dynamically |

## Prerequisites

- [Node.js LTS](https://nodejs.org) (v22 or later recommended)

## Run Locally

Install dependencies:

```sh
npm install
```

Run a demo:

```sh
npm run demo1
# or
npm run demo2
```

Inspect a demo with the MCP Inspector:

```sh
npm run inspect1
# or
npm run inspect2
```

## VS Code MCP Server

The `.vscode/mcp.json` file registers the following servers for use in Copilot:

- **pluralsight-module-2-roots-demo-1**: Runs Demo 1 (directory scan on connect)
- **pluralsight-module-2-roots-demo-2**: Runs Demo 2 (dynamic root change tracking)
import json
import uuid
from enum import Enum

from fastmcp import FastMCP
from pydantic import BaseModel

# ---------------------------------------------------------------------------
# Domain models
# ---------------------------------------------------------------------------

class ProposalStatus(str, Enum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    REJECTED = "rejected"


class Proposal(BaseModel):
    id: str
    title: str
    speaker: str
    topic: str
    abstract: str
    status: ProposalStatus


# ---------------------------------------------------------------------------
# In-memory store
# ---------------------------------------------------------------------------

TOPICS: list[str] = [
    "Programming Languages",
    "Software Architecture",
    "Cloud & Infrastructure",
    "Security",
    "Data & AI",
    "DevOps & Platform Engineering",
    "Developer Experience",
]

_proposals: dict[str, Proposal] = {}


def _seed_proposals() -> None:
    seed_data = [
        Proposal(
            id="prop-001",
            title="Designing for Failure: Resilience Patterns in Distributed Systems",
            speaker="Priya Nair",
            topic="Software Architecture",
            abstract=(
                "This talk explores practical resilience patterns—circuit breakers, "
                "bulkheads, and chaos engineering—through real-world case studies. "
                "Attendees will leave with actionable techniques for building systems "
                "that degrade gracefully under failure."
            ),
            status=ProposalStatus.PENDING,
        ),
        Proposal(
            id="prop-002",
            title="Zero Trust in Practice: Beyond the Buzzword",
            speaker="Marcus Webb",
            topic="Security",
            abstract=(
                "Zero Trust is widely discussed but rarely implemented correctly. "
                "This session breaks down the core principles—verify explicitly, "
                "least-privilege access, assume breach—and demonstrates how to apply "
                "them incrementally in an existing enterprise environment."
            ),
            status=ProposalStatus.PENDING,
        ),
        Proposal(
            id="prop-003",
            title="Platform Engineering Decoded: Building Internal Developer Portals",
            speaker="Sofia Andersson",
            topic="DevOps & Platform Engineering",
            abstract=(
                "Internal developer portals (IDPs) are becoming the backbone of "
                "developer experience at scale. This talk covers the key capabilities "
                "of an IDP, common pitfalls teams encounter, and a live walkthrough of "
                "a Backstage-based portal serving 200+ engineers."
            ),
            status=ProposalStatus.ACCEPTED,
        ),
        Proposal(
            id="prop-004",
            title="LLMs as Reasoning Engines: Practical Patterns for Agentic AI",
            speaker="James Okafor",
            topic="Data & AI",
            abstract=(
                "Large language models are most powerful when used as reasoning engines "
                "inside multi-step agentic workflows. This talk covers tool use, "
                "reflection loops, and memory strategies with concrete code examples "
                "using open-source frameworks."
            ),
            status=ProposalStatus.PENDING,
        ),
    ]
    for proposal in seed_data:
        _proposals[proposal.id] = proposal


_seed_proposals()


# ---------------------------------------------------------------------------
# MCP server
# ---------------------------------------------------------------------------

mcp = FastMCP(
    name="CFP Manager",
    instructions=(
        "A Call for Papers management server. Use the available tools to submit "
        "and manage conference proposals, read proposal data via resources, and "
        "generate structured review prompts."
    ),
)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@mcp.tool
def submit_proposal(
    title: str,
    speaker: str,
    topic: str,
    abstract: str,
) -> Proposal:
    """Submit a new conference proposal. Returns the created proposal with its
    assigned ID and an initial status of 'pending'."""
    proposal = Proposal(
        id=f"prop-{uuid.uuid4().hex[:6]}",
        title=title,
        speaker=speaker,
        topic=topic,
        abstract=abstract,
        status=ProposalStatus.PENDING,
    )
    _proposals[proposal.id] = proposal
    return proposal


@mcp.tool
def update_proposal_status(proposal_id: str, status: ProposalStatus) -> Proposal:
    """Update the status of an existing proposal. Valid statuses are 'pending',
    'accepted', and 'rejected'. Returns the updated proposal."""
    if proposal_id not in _proposals:
        raise ValueError(f"Proposal '{proposal_id}' not found.")
    _proposals[proposal_id].status = status
    return _proposals[proposal_id]


@mcp.tool
def get_proposal(proposal_id: str) -> Proposal:
    """Retrieve a single proposal by its ID."""
    if proposal_id not in _proposals:
        raise ValueError(f"Proposal '{proposal_id}' not found.")
    return _proposals[proposal_id]


# ---------------------------------------------------------------------------
# Resources
# ---------------------------------------------------------------------------

@mcp.resource("cfp://proposals")
def list_proposals() -> str:
    """A JSON list of all submitted conference proposals."""
    return json.dumps(
        [p.model_dump() for p in _proposals.values()],
        indent=2,
    )


@mcp.resource("cfp://topics")
def list_topics() -> str:
    """A JSON list of accepted topic categories for the conference."""
    return json.dumps(TOPICS, indent=2)


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

@mcp.prompt
def review_proposal(title: str, abstract: str) -> str:
    """Generate a structured review prompt for a conference proposal.
    Returns a prompt that asks an LLM to evaluate the proposal on fit,
    originality, and clarity."""
    return f"""You are an experienced program committee member reviewing a conference proposal.

Evaluate the following proposal and provide a structured review.

## Proposal

**Title:** {title}

**Abstract:**
{abstract}

## Review Criteria

Score each criterion from 1 (poor) to 5 (excellent) and provide a short justification.

1. **Fit** – Is the topic relevant to a broad software developer audience?
2. **Originality** – Does the talk offer a fresh perspective or novel insight?
3. **Clarity** – Is the abstract well-written and the scope clearly defined?

## Output Format

Respond in the following structure:

- Fit: <score>/5 — <justification>
- Originality: <score>/5 — <justification>
- Clarity: <score>/5 — <justification>
- Overall recommendation: Accept | Reject | Request revisions
- Summary: <one or two sentences>
"""


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    mcp.run()

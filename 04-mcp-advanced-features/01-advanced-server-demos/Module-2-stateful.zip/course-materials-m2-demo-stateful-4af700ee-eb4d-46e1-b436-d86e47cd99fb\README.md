## Stateful Demo

This demo hosts a remote MCP server on Cloudflare using the `McpAgent` class from the Agents SDK, which provides per-connection state through Cloudflare Durable Objects. Each client session gets its own persistent `McpAgent` instance, demonstrating how stateful MCP servers differ from request-scoped stateless handlers.

## Features / Skills Covered

- **`McpAgent`**: Extending the `McpAgent` class to create a stateful Cloudflare Workers MCP server
- **Durable Objects**: Per-connection server instances that persist state across requests within a session
- **Session identity**: Reading `extra.sessionId` inside tool handlers to identify the current client connection

## Prerequisites

- [Node.js LTS](https://nodejs.org) (v22 or later recommended)
- [Cloudflare account](https://dash.cloudflare.com/sign-up) — required for Wrangler and Durable Objects
- [Wrangler CLI](https://developers.cloudflare.com/workers/wrangler/install-and-update/) — authenticate once with `npx wrangler login`

## Run Locally

Install dependencies:

```sh
npm install
```

Start the dev server (runs on `http://127.0.0.1:8787/mcp`):

```sh
npm start
```

Inspect with the MCP Inspector:

```sh
npm run inspect
```

## Deploy to Cloudflare

```sh
npm run deploy
```

You can use the [Cloudflare AI Playground](https://playground.ai.cloudflare.com/) to test the MCP server remotely or connect to it using MCP Inspector locally.

## Resources

- [Build a remote MCP server](https://developers.cloudflare.com/agents/guides/remote-mcp-server/)
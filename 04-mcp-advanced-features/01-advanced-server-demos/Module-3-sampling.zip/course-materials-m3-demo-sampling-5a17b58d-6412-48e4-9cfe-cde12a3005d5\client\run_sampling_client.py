"""FastMCP client for exercising the local sampling-with-tools demo server.

This script supports two modes:

- probe: verify the HTTP MCP endpoint is reachable and list its tools
- anthropic: run the sampling flow with Anthropic once ANTHROPIC_API_KEY is set
"""

from __future__ import annotations

import asyncio
import os
from typing import Any

from fastmcp import Client
from fastmcp.client.sampling import SamplingMessage, SamplingParams
from fastmcp.client.sampling.handlers.anthropic import AnthropicSamplingHandler
from mcp.types import (
    CreateMessageResultWithTools,
    SamplingCapability,
    SamplingToolsCapability,
)

from util import build_parser, format_payload, load_local_env, unwrap_result
    
class LoggingAnthropicHandler(AnthropicSamplingHandler):
    """Anthropic handler with simple console logging for sampling flow visibility."""

    async def __call__(
        self,
        messages: list[SamplingMessage],
        params: SamplingParams,
        context: Any,
    ) -> CreateMessageResultWithTools | Any:
        tools = getattr(params, "tools", None) or []
        print(
            f"[sampling] sending {len(messages)} message(s) to Anthropic with {len(tools)} tool(s)"
        )
        response = await super().__call__(messages, params, context)
        print("[sampling] received response from Anthropic")
        return response
    
async def async_main() -> None:
    load_local_env()

    parser = build_parser()
    args = parser.parse_args()

    if args.mode == "probe":
        await probe_server(args.server_url)
        return

    if not os.environ.get("ANTHROPIC_API_KEY"):
        raise SystemExit(
            "ANTHROPIC_API_KEY is not set. Add it to client/.env before running plan mode."
        )

    handler = LoggingAnthropicHandler(default_model=args.model)
    await run_trip(args.server_url, args.destination, args.days, handler)


async def probe_server(server_url: str) -> None:
    """Verify the server is reachable and enumerate tools."""
    async with Client(server_url) as client:
        await client.ping()
        tools = await client.list_tools()

    print(f"Connected to {server_url}")
    print("Available tools:")
    for tool in tools:
        print(f"- {tool.name}: {tool.description}")


async def run_trip(server_url: str, destination: str, days: int, handler: Any) -> None:
    """Invoke the server's sampling-enabled plan_trip tool."""
    async with Client(
        server_url,
        sampling_handler=handler,
        sampling_capabilities=SamplingCapability(
            tools=SamplingToolsCapability(),
        ),
    ) as client:
        result = await client.call_tool(
            "plan_trip",
            {"destination": destination, "days": days},
        )

    payload = unwrap_result(result)
    print(format_payload(payload))
    
def main() -> None:
    asyncio.run(async_main())

if __name__ == "__main__":
    main()
import { AgentWorkflow } from "agents/workflows";
import type { AgentWorkflowEvent, AgentWorkflowStep } from "agents/workflows";
import type { TripPlannerAgent } from "./server";

type Params = { task: string };

const STEPS = [
  { name: "get_user_events", task: "Get user's upcoming calendar events", tool: "gcal.get_events" },
  { name: "find_next_flight_event", task: "Find next event with flight information" },
  {
    name: "search_flight_status",
    task: "Search for current status of the next flight",
    tool: "gflights.get_flight_details",
  },
  { name: "report_flight_status", task: "Report flight status to the user" },
];

const TOOLS = [
  {
    name: "gcal.get_events",
    description: "Get the user's upcoming calendar events",
  },
  {
    name: "gflights.get_flight_details",
    description: "Find events with flight information",
  },
];

export class FlightSearchWorkflow extends AgentWorkflow<
  TripPlannerAgent,
  Params
> {
  async run(event: AgentWorkflowEvent<Params>, step: AgentWorkflowStep) {

    console.log("[workflow] Starting flight search workflow with event:", event);

    // Durable agent loop - each turn is checkpointed
    for (let stepIndex = 0; stepIndex < STEPS.length; stepIndex++) {
      // Report progress to Agent and connected clients
      const task = STEPS[stepIndex].task;
      await this.reportProgress({
        step: task,
        status: "running",
        percent: stepIndex / STEPS.length,
        message: `Starting step: ${task}`,
      });

      await step.do(task, async () => {
        const toolName = STEPS[stepIndex].tool;
        const tool = TOOLS.find((t) => t.name === toolName);

        if (tool) {
          // Broadcast tool execution to clients
          this.broadcastToClients({
            type: "tool_call",
            tool: tool.name,
            step: stepIndex + 1,
          });
        }

        await step.sleep("pause", "3 seconds");

        return {
          task
        }
      });
    }

    const result = {
      status: "complete",
      message: "Found next flight and reported status to user",
      data: {
        flight: "Flight XYZ123 on time",
        departing: "Minneapolis-Saint Paul International Airport",
        destination: "Boston Logan Airport",
        departureTime: "2027-05-01T15:00:00",
        arrivalTime: "2027-05-01T17:00:00",
      }
    };

    // Report completion (durable)
    await step.reportComplete(result);
    return result;
  }
}
